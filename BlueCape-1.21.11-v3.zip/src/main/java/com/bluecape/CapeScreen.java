package com.bluecape;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Stream;

/**
 * The cape screen: a list of your newest photos (gallery folders + config/bluecape/photos),
 * a box to paste a file path, and a few options. Open it with the "Cape" button
 * in the top-left corner of the title screen or the pause menu.
 */
public class CapeScreen extends Screen {
    private record Photo(Path path, long time) {
    }

    private final Screen parent;
    private final List<Path> photos = new ArrayList<>();
    private ButtonWidget[] rowButtons = new ButtonWidget[0];
    private ButtonWidget prevButton;
    private ButtonWidget nextButton;
    private TextFieldWidget pathField;
    private String pathText = "";
    private TextFieldWidget colorField;
    private String colorText = CapeSettings.colorHex;
    private int page;
    private int rows = 1;
    private int navY;
    private Text status = Text.literal("Tap a photo, paste a path, or type a color code.");

    public CapeScreen(Screen parent) {
        super(Text.literal("Blue Cape"));
        this.parent = parent;
    }

    /** The small "Cape" button the mixins add to the title screen and the pause menu. */
    public static ButtonWidget openButton(Screen current) {
        return ButtonWidget.builder(Text.literal("Cape"),
                        button -> MinecraftClient.getInstance().setScreen(new CapeScreen(current)))
                .dimensions(4, 4, 44, 20)
                .build();
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int left = cx - 100;
        int h = this.height;
        this.rows = Math.max(1, Math.min(8, (h - 194) / 22));
        this.navY = h - 160;
        scanPhotos();

        this.rowButtons = new ButtonWidget[rows];
        for (int i = 0; i < rows; i++) {
            final int slot = i;
            rowButtons[i] = this.addDrawableChild(ButtonWidget.builder(Text.empty(), button -> pickRow(slot))
                    .dimensions(left, 34 + i * 22, 200, 20).build());
        }

        prevButton = this.addDrawableChild(ButtonWidget.builder(Text.literal("< Prev"), button -> {
            page--;
            refreshRows();
        }).dimensions(left, navY, 60, 20).build());
        nextButton = this.addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), button -> {
            page++;
            refreshRows();
        }).dimensions(left + 140, navY, 60, 20).build());

        pathField = new TextFieldWidget(this.textRenderer, left, h - 124, 200, 20, Text.literal("Photo path"));
        pathField.setMaxLength(1024);
        pathField.setText(pathText);
        pathField.setChangedListener(s -> pathText = s);
        this.addDrawableChild(pathField);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Use this path"), button -> usePath())
                .dimensions(left, h - 102, 98, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Rescan photos"), button -> {
            scanPhotos();
            page = 0;
            refreshRows();
            status = Text.literal(photos.size() + " photos found.");
        }).dimensions(left + 102, h - 102, 98, 20).build());

        colorField = new TextFieldWidget(this.textRenderer, left, h - 80, 98, 20, Text.literal("Color code"));
        colorField.setMaxLength(9);
        colorField.setText(colorText);
        colorField.setChangedListener(s -> colorText = s);
        this.addDrawableChild(colorField);
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Apply color"), button -> applyColor())
                .dimensions(left + 102, h - 80, 98, 20).build());

        this.addDrawableChild(ButtonWidget.builder(fitLabel(), button -> {
            CapeSettings.fit = CapeSettings.fit == CapeComposer.Fit.FILL ? CapeComposer.Fit.FIT : CapeComposer.Fit.FILL;
            CapeSettings.save();
            button.setMessage(fitLabel());
            reapply();
        }).dimensions(left, h - 58, 98, 20).build());
        this.addDrawableChild(ButtonWidget.builder(modeLabel(), button -> {
            CapeSettings.readyMade = !CapeSettings.readyMade;
            CapeSettings.save();
            button.setMessage(modeLabel());
            reapply();
        }).dimensions(left + 102, h - 58, 98, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Default blue"), button -> {
            CapeManager.useDefault();
            status = Text.literal("Back to the default blue cape.");
        }).dimensions(left, h - 36, 98, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> this.close())
                .dimensions(left + 102, h - 36, 98, 20).build());

        refreshRows();
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int cx = this.width / 2;
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, 10, 0xFFFFFFFF);
        String header = photos.isEmpty()
                ? "No photos found. Paste a path below or copy photos to config/bluecape/photos"
                : "Your photos (newest first)";
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(header), cx, 22, 0xFFA0A0A0);
        int pages = Math.max(1, (photos.size() + rows - 1) / rows);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal((page + 1) + " / " + pages), cx, navY + 6, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Or paste a photo path:"), cx, this.height - 136, 0xFFA0A0A0);
        context.drawCenteredTextWithShadow(this.textRenderer, status, cx, this.height - 12, 0xFFFFFFFF);
    }

    // ------------------------------------------------------------------ actions

    private void pickRow(int slot) {
        int index = page * rows + slot;
        if (index < photos.size()) {
            apply(photos.get(index));
        }
    }

    private void usePath() {
        String s = pathText.trim();
        if (s.length() >= 2 && ((s.startsWith("\"") && s.endsWith("\"")) || (s.startsWith("'") && s.endsWith("'")))) {
            s = s.substring(1, s.length() - 1).trim();
        }
        if (s.isEmpty()) {
            status = Text.literal("Paste the path of a photo first.");
            return;
        }
        try {
            apply(Path.of(s));
        } catch (InvalidPathException e) {
            status = Text.literal("That doesn't look like a file path.");
        }
    }

    private void applyColor() {
        int rgb = CapeComposer.parseHex(colorText);
        if (rgb < 0) {
            status = Text.literal("Type a color code: 6 letters/numbers, like 1085EE.");
            return;
        }
        String hex = String.format("#%06X", rgb);
        CapeManager.useColor(rgb);
        CapeSettings.colorHex = hex;
        CapeSettings.save();
        colorField.setText(hex);
        status = Text.literal("Cape color set to " + hex);
    }

    private void reapply() {
        if (CapeSettings.lastPath.isEmpty()) {
            return;
        }
        try {
            apply(Path.of(CapeSettings.lastPath));
        } catch (InvalidPathException ignored) {
            // nothing to redo
        }
    }

    private void apply(Path file) {
        status = Text.literal("Working...");
        CapeSettings.lastPath = file.toString();
        CapeSettings.save();
        CapeManager.importFile(file).thenAccept(message -> status = Text.literal(message));
    }

    private void refreshRows() {
        int pages = Math.max(1, (photos.size() + rows - 1) / rows);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int i = 0; i < rows; i++) {
            int index = page * rows + i;
            ButtonWidget button = rowButtons[i];
            if (index < photos.size()) {
                button.visible = true;
                button.setMessage(Text.literal(label(photos.get(index))));
            } else {
                button.visible = false;
            }
        }
        prevButton.active = page > 0;
        nextButton.active = page < pages - 1;
    }

    private static Text fitLabel() {
        return Text.literal("Photo: " + (CapeSettings.fit == CapeComposer.Fit.FILL ? "Fill" : "Fit whole"));
    }

    private static Text modeLabel() {
        return Text.literal("Mode: " + (CapeSettings.readyMade ? "Cape file" : "Photo"));
    }

    private static String label(Path p) {
        String name = p.getFileName().toString();
        return name.length() > 30 ? name.substring(0, 27) + "..." : name;
    }

    // ------------------------------------------------------------------ finding photos

    private static List<Path> photoDirs() {
        List<Path> dirs = new ArrayList<>();
        dirs.add(CapeSettings.dir().resolve("photos"));
        String[] relative = {"DCIM/Camera", "DCIM", "Pictures", "Pictures/Screenshots", "DCIM/Screenshots", "Download"};
        for (String root : new String[]{"/storage/emulated/0", "/sdcard"}) {
            for (String rel : relative) {
                dirs.add(Path.of(root, rel));
            }
        }
        dirs.add(FabricLoader.getInstance().getGameDir().resolve("screenshots"));
        return dirs;
    }

    private static boolean isImage(Path p) {
        String name = p.getFileName().toString().toLowerCase(Locale.ROOT);
        return !name.startsWith(".") && (name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg")
                || name.endsWith(".bmp") || name.endsWith(".gif") || name.endsWith(".tga"));
    }

    private static Path key(Path p) {
        try {
            return p.toRealPath();
        } catch (IOException e) {
            return p.toAbsolutePath().normalize();
        }
    }

    private void scanPhotos() {
        photos.clear();
        Set<Path> seen = new HashSet<>();
        List<Photo> found = new ArrayList<>();
        for (Path dir : photoDirs()) {
            try (Stream<Path> files = Files.list(dir)) {
                for (Path p : (Iterable<Path>) files::iterator) {
                    if (isImage(p) && Files.isRegularFile(p) && seen.add(key(p))) {
                        found.add(new Photo(p, Files.getLastModifiedTime(p).toMillis()));
                    }
                }
            } catch (Exception ignored) {
                // folder missing or not readable: skip it
            }
        }
        found.sort(Comparator.comparingLong(Photo::time).reversed());
        for (int i = 0; i < Math.min(found.size(), 300); i++) {
            photos.add(found.get(i).path());
        }
    }
}
