package com.bluecape;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Draws the little cape / elytra pictures on the screens, using plain coloured squares. */
final class PreviewDraw {
    private static final int FRAME = 0xFF1B1B1B;

    private PreviewDraw() {
    }

    /** The outside of the cape. colors is CapeComposer.PREVIEW_W x PREVIEW_H. */
    static void cape(DrawContext c, int x, int y, int cell, int[] colors) {
        if (colors == null) {
            return;
        }
        frame(c, x, y, CapeComposer.PREVIEW_W * cell, CapeComposer.PREVIEW_H * cell);
        grid(c, x, y, cell, colors, CapeComposer.PREVIEW_W, CapeComposer.PREVIEW_H, false);
    }

    /** Both wings of the elytra, side by side. wing is CapeComposer.WING_W x WING_H. */
    static void wings(DrawContext c, int x, int y, int cell, int[] wing) {
        if (wing == null) {
            return;
        }
        int w = CapeComposer.WING_W * cell;
        grid(c, x, y, cell, wing, CapeComposer.WING_W, CapeComposer.WING_H, false);
        grid(c, x + w, y, cell, wing, CapeComposer.WING_W, CapeComposer.WING_H, true);
    }

    /** A plain square of one colour (0xRRGGBB) with a thin dark frame. */
    static void swatch(DrawContext c, int x, int y, int w, int h, int rgb) {
        frame(c, x, y, w, h);
        c.fill(x, y, x + w, y + h, 0xFF000000 | rgb);
    }

    /** Centered text that wraps onto more lines when it is wider than maxWidth. Returns the y below the last line. */
    static int textBlock(DrawContext c, TextRenderer r, String text, int centerX, int y, int maxWidth, int color) {
        for (String line : wrap(r, text, maxWidth)) {
            c.drawCenteredTextWithShadow(r, Text.literal(line), centerX, y, color);
            y += 11;
        }
        return y;
    }

    /** How many lines textBlock will use. */
    static int lineCount(TextRenderer r, String text, int maxWidth) {
        return wrap(r, text, maxWidth).size();
    }

    private static List<String> wrap(TextRenderer r, String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return lines;
        }
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            // a single word that is too wide on its own (a long path): cut it into pieces
            while (r.getWidth(word) > maxWidth && word.length() > 1) {
                int cut = word.length() - 1;
                while (cut > 1 && r.getWidth(word.substring(0, cut)) > maxWidth) {
                    cut--;
                }
                if (line.length() > 0) {
                    lines.add(line.toString());
                    line.setLength(0);
                }
                lines.add(word.substring(0, cut));
                word = word.substring(cut);
            }
            String candidate = line.length() == 0 ? word : line + " " + word;
            if (line.length() > 0 && r.getWidth(candidate) > maxWidth) {
                lines.add(line.toString());
                line.setLength(0);
                line.append(word);
            } else {
                line.setLength(0);
                line.append(candidate);
            }
        }
        if (line.length() > 0) {
            lines.add(line.toString());
        }
        return lines;
    }

    private static void frame(DrawContext c, int x, int y, int w, int h) {
        c.fill(x - 1, y - 1, x + w + 1, y, FRAME);
        c.fill(x - 1, y + h, x + w + 1, y + h + 1, FRAME);
        c.fill(x - 1, y, x, y + h, FRAME);
        c.fill(x + w, y, x + w + 1, y + h, FRAME);
    }

    /** One fill per run of equal colours in a row, so a flat colour costs only a few draw calls. */
    private static void grid(DrawContext c, int x, int y, int cell, int[] colors, int cols, int rows, boolean mirror) {
        for (int j = 0; j < rows; j++) {
            int start = 0;
            while (start < cols) {
                int color = colors[j * cols + (mirror ? cols - 1 - start : start)];
                int end = start + 1;
                while (end < cols && colors[j * cols + (mirror ? cols - 1 - end : end)] == color) {
                    end++;
                }
                if ((color >>> 24) >= 26) {                  // see-through cells are left empty
                    c.fill(x + start * cell, y + j * cell, x + end * cell, y + (j + 1) * cell, 0xFF000000 | color);
                }
                start = end;
            }
        }
    }
}
