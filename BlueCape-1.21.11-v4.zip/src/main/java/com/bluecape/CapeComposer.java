package com.bluecape;

import java.util.Arrays;

/**
 * Builds the cape texture (512x256 = a 64x32 cape layout scaled up by 8).
 * Pure Java on purpose: it knows nothing about Minecraft, so it can be tested on its own.
 *
 * Cape layout in 64x32 units:
 *   outside of the cape  x=1..11,  y=1..17
 *   inside of the cape   x=12..22, y=1..17
 *   elytra wings         x=24..34 / x=36..46, y=2..22
 */
public final class CapeComposer {
    public static final int SCALE = 8;
    public static final int W = 64 * SCALE;
    public static final int H = 32 * SCALE;
    /** The blue from the screenshot (#1085EE). */
    public static final int BLUE = 0xFF1085EE;

    public enum Fit { FILL, FIT }

    /** Anything that can hand out ARGB pixels. */
    public interface Pixels {
        int width();

        int height();

        int argb(int x, int y);
    }

    private CapeComposer() {
    }

    /** The default cape: flat blue everywhere. (The elytra is the game's own elytra, tinted blue.) */
    public static int[] defaultCape() {
        return solid(BLUE);
    }

    /** A cape in one flat colour (0xRRGGBB). */
    public static int[] solid(int rgb) {
        int[] out = new int[W * H];
        Arrays.fill(out, 0xFF000000 | (rgb & 0xFFFFFF));
        return out;
    }

    /**
     * Tints the game's own elytra texture to one colour (0xRRGGBB). The feathers, the shading and
     * the see-through parts stay exactly as in the vanilla elytra, only the colour changes.
     * Returns ARGB pixels, same size as the source.
     */
    public static int[] recolorElytra(Pixels src, int rgb) {
        int w = src.width();
        int h = src.height();
        // the target colour as hue / saturation / lightness
        double r0 = ((rgb >> 16) & 0xFF) / 255.0;
        double g0 = ((rgb >> 8) & 0xFF) / 255.0;
        double b0 = (rgb & 0xFF) / 255.0;
        double max = Math.max(r0, Math.max(g0, b0));
        double min = Math.min(r0, Math.min(g0, b0));
        double light = (max + min) / 2;
        double sat = max == min ? 0 : (max - min) / (1 - Math.abs(2 * light - 1));
        double hue;
        if (max == min) {
            hue = 0;
        } else if (max == r0) {
            hue = ((g0 - b0) / (max - min) + 6) % 6;
        } else if (max == g0) {
            hue = (b0 - r0) / (max - min) + 2;
        } else {
            hue = (r0 - g0) / (max - min) + 4;
        }

        double sum = 0;
        long count = 0;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int c = src.argb(x, y);
                if ((c >>> 24) != 0) {
                    sum += luma(c);
                    count++;
                }
            }
        }
        double mean = count == 0 ? 0.5 : Math.max(0.05, sum / count);
        int[] out = new int[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int c = src.argb(x, y);
                int a = c >>> 24;
                if (a == 0) {
                    out[y * w + x] = 0;
                    continue;
                }
                // how much lighter or darker than the average pixel this one is: that shading is kept
                double f = luma(c) / mean;
                double l = f <= 1 ? light * f : light + (1 - light) * Math.min(1.0, (f - 1) * 0.6);
                out[y * w + x] = (a << 24) | hslToRgb(hue, sat, l);
            }
        }
        return out;
    }

    private static int hslToRgb(double hue, double sat, double light) {
        double c = (1 - Math.abs(2 * light - 1)) * sat;
        double hp = hue % 6;
        double x = c * (1 - Math.abs(hp % 2 - 1));
        double r = 0;
        double g = 0;
        double b = 0;
        if (hp < 1) {
            r = c;
            g = x;
        } else if (hp < 2) {
            r = x;
            g = c;
        } else if (hp < 3) {
            g = c;
            b = x;
        } else if (hp < 4) {
            g = x;
            b = c;
        } else if (hp < 5) {
            r = x;
            b = c;
        } else {
            r = c;
            b = x;
        }
        double m = light - c / 2;
        int ri = clamp((int) Math.round((r + m) * 255), 0, 255);
        int gi = clamp((int) Math.round((g + m) * 255), 0, 255);
        int bi = clamp((int) Math.round((b + m) * 255), 0, 255);
        return (ri << 16) | (gi << 8) | bi;
    }

    private static double luma(int argb) {
        int r = (argb >> 16) & 0xFF;
        int g = (argb >> 8) & 0xFF;
        int b = argb & 0xFF;
        return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0;
    }

    /** The average colour (0xRRGGBB) of the outside of the cape in a cape texture made by this class. */
    public static int averageColor(int[] cape) {
        long r = 0;
        long g = 0;
        long b = 0;
        long n = 0;
        for (int y = 1 * SCALE; y < 17 * SCALE; y++) {
            for (int x = 1 * SCALE; x < 11 * SCALE; x++) {
                int c = cape[y * W + x];
                if ((c >>> 24) != 0) {
                    r += (c >> 16) & 0xFF;
                    g += (c >> 8) & 0xFF;
                    b += c & 0xFF;
                    n++;
                }
            }
        }
        if (n == 0) {
            return BLUE & 0xFFFFFF;
        }
        return ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
    }

    /**
     * Reads a colour code like "#1085EE", "1085ee", "0x1085EE" or the short "18E".
     * Returns 0xRRGGBB, or -1 when the text is not a colour code.
     */
    public static int parseHex(String text) {
        if (text == null) {
            return -1;
        }
        String s = text.trim();
        if (s.startsWith("#")) {
            s = s.substring(1);
        } else if (s.startsWith("0x") || s.startsWith("0X")) {
            s = s.substring(2);
        }
        if (s.length() != 3 && s.length() != 6) {
            return -1;
        }
        int value = 0;
        for (int i = 0; i < s.length(); i++) {
            int digit = Character.digit(s.charAt(i), 16);
            if (digit < 0) {
                return -1;
            }
            value = value * 16 + digit;
        }
        if (s.length() == 3) {
            int r = (value >> 8) & 15;
            int g = (value >> 4) & 15;
            int b = value & 15;
            value = ((r * 17) << 16) | ((g * 17) << 8) | (b * 17);
        }
        return value;
    }

    /** Puts a photo on the outside of the cape (and on the elytra wings). */
    public static int[] fromPhoto(Pixels src, Fit fit) {
        int avg = average(src);
        int[] out = new int[W * H];
        Arrays.fill(out, avg);
        fillRect(out, 12, 1, 10, 16, darken(avg, 0.8f));
        blit(out, src, 1, 1, 10, 16, fit);
        blit(out, src, 24, 2, 10, 20, fit);
        blit(out, src, 36, 2, 10, 20, fit);
        return out;
    }

    /** Uses an image that already is a cape texture (64x32 style, or 46x22 old style). */
    public static int[] fromReadyMade(Pixels src) {
        int sw = src.width();
        int sh = src.height();
        double ratio = (double) sw / sh;
        double fw;
        if (Math.abs(ratio - 2.0) < 0.02) {
            fw = 64;
        } else if (Math.abs(ratio - 46.0 / 22.0) < 0.02) {
            fw = 46;
        } else {
            throw new IllegalArgumentException("A cape file must be 2:1 (like 64x32 or 512x256). This image is " + sw + "x" + sh + ".");
        }
        double k = sw / fw; // source pixels per cape unit
        int[] out = new int[W * H];
        for (int y = 0; y < H; y++) {
            double v0 = y * (32.0 / H) * k;
            double v1 = (y + 1) * (32.0 / H) * k;
            for (int x = 0; x < W; x++) {
                double u0 = x * (64.0 / W) * k;
                double u1 = (x + 1) * (64.0 / W) * k;
                if (u0 >= sw || v0 >= sh) {
                    out[y * W + x] = BLUE;
                } else {
                    out[y * W + x] = sample(src, u0, v0, Math.min(u1, sw), Math.min(v1, sh));
                }
            }
        }
        return out;
    }

    /** Wraps pixels so a phone photo with an EXIF rotation tag comes out the right way up. */
    public static Pixels oriented(Pixels raw, int orientation) {
        if (orientation < 2 || orientation > 8) {
            return raw;
        }
        final int sw = raw.width();
        final int sh = raw.height();
        final boolean swap = orientation >= 5;
        return new Pixels() {
            @Override
            public int width() {
                return swap ? sh : sw;
            }

            @Override
            public int height() {
                return swap ? sw : sh;
            }

            @Override
            public int argb(int x, int y) {
                switch (orientation) {
                    case 2:
                        return raw.argb(sw - 1 - x, y);
                    case 3:
                        return raw.argb(sw - 1 - x, sh - 1 - y);
                    case 4:
                        return raw.argb(x, sh - 1 - y);
                    case 5:
                        return raw.argb(y, x);
                    case 6:
                        return raw.argb(y, sh - 1 - x);
                    case 7:
                        return raw.argb(sw - 1 - y, sh - 1 - x);
                    default: // 8
                        return raw.argb(sw - 1 - y, x);
                }
            }
        };
    }

    /** Reads the EXIF orientation (1..8) from JPEG bytes; 1 when there is none. */
    public static int exifOrientation(byte[] d) {
        if (d.length < 4 || (d[0] & 0xFF) != 0xFF || (d[1] & 0xFF) != 0xD8) {
            return 1;
        }
        int p = 2;
        while (p + 4 <= d.length) {
            if ((d[p] & 0xFF) != 0xFF) {
                return 1;
            }
            int marker = d[p + 1] & 0xFF;
            if (marker == 0xD8 || marker == 0x01 || (marker >= 0xD0 && marker <= 0xD7)) {
                p += 2;
                continue;
            }
            if (marker == 0xDA || marker == 0xD9) {
                return 1;
            }
            int len = ((d[p + 2] & 0xFF) << 8) | (d[p + 3] & 0xFF);
            if (marker == 0xE1 && len >= 8 && p + 10 <= d.length
                    && d[p + 4] == 'E' && d[p + 5] == 'x' && d[p + 6] == 'i' && d[p + 7] == 'f'
                    && d[p + 8] == 0 && d[p + 9] == 0) {
                return tiffOrientation(d, p + 10, Math.min(d.length, p + 2 + len));
            }
            p += 2 + len;
        }
        return 1;
    }

    private static int tiffOrientation(byte[] d, int base, int end) {
        if (base + 8 > end) {
            return 1;
        }
        boolean le;
        if (d[base] == 'I' && d[base + 1] == 'I') {
            le = true;
        } else if (d[base] == 'M' && d[base + 1] == 'M') {
            le = false;
        } else {
            return 1;
        }
        long ifdOffset = u32(d, base + 4, le);
        if (ifdOffset < 8 || base + ifdOffset + 2 > end) {
            return 1;
        }
        int ifd = (int) (base + ifdOffset);
        int count = u16(d, ifd, le);
        for (int i = 0; i < count; i++) {
            int e = ifd + 2 + i * 12;
            if (e + 12 > end) {
                break;
            }
            if (u16(d, e, le) == 0x0112) {
                int v = u16(d, e + 8, le);
                return (v >= 1 && v <= 8) ? v : 1;
            }
        }
        return 1;
    }

    private static int u16(byte[] d, int o, boolean le) {
        int a = d[o] & 0xFF;
        int b = d[o + 1] & 0xFF;
        return le ? (b << 8) | a : (a << 8) | b;
    }

    private static long u32(byte[] d, int o, boolean le) {
        long a = u16(d, o, le);
        long b = u16(d, o + 2, le);
        return le ? (b << 16) | a : (a << 16) | b;
    }

    // ---------------------------------------------------------------- drawing helpers

    private static void blit(int[] out, Pixels src, int ux, int uy, int uw, int uh, Fit fit) {
        int rx = ux * SCALE;
        int ry = uy * SCALE;
        int rw = uw * SCALE;
        int rh = uh * SCALE;
        int sw = src.width();
        int sh = src.height();
        double dstAspect = (double) rw / rh;
        double srcAspect = (double) sw / sh;
        double cx = 0;
        double cy = 0;
        double cw = sw;
        double ch = sh;
        int dx = 0;
        int dy = 0;
        int dw = rw;
        int dh = rh;
        if (fit == Fit.FILL) {
            if (srcAspect > dstAspect) {
                cw = sh * dstAspect;
                cx = (sw - cw) / 2;
            } else {
                ch = sw / dstAspect;
                cy = (sh - ch) / 2;
            }
        } else {
            if (srcAspect > dstAspect) {
                dh = Math.max(1, (int) Math.round(rw / srcAspect));
                dy = (rh - dh) / 2;
            } else {
                dw = Math.max(1, (int) Math.round(rh * srcAspect));
                dx = (rw - dw) / 2;
            }
        }
        for (int y = 0; y < dh; y++) {
            double v0 = cy + y * ch / dh;
            double v1 = cy + (y + 1) * ch / dh;
            for (int x = 0; x < dw; x++) {
                double u0 = cx + x * cw / dw;
                double u1 = cx + (x + 1) * cw / dw;
                out[(ry + dy + y) * W + rx + dx + x] = flatten(sample(src, u0, v0, u1, v1), BLUE);
            }
        }
    }

    private static void fillRect(int[] out, int ux, int uy, int uw, int uh, int color) {
        for (int y = uy * SCALE; y < (uy + uh) * SCALE; y++) {
            for (int x = ux * SCALE; x < (ux + uw) * SCALE; x++) {
                out[y * W + x] = color;
            }
        }
    }

    /** Average colour of a source rectangle (a few samples per output pixel, alpha-aware). */
    static int sample(Pixels src, double u0, double v0, double u1, double v1) {
        int nx = clamp((int) Math.ceil(u1 - u0), 1, 4);
        int ny = clamp((int) Math.ceil(v1 - v0), 1, 4);
        long sa = 0;
        long sr = 0;
        long sg = 0;
        long sb = 0;
        for (int j = 0; j < ny; j++) {
            int py = clamp((int) (v0 + (j + 0.5) * (v1 - v0) / ny), 0, src.height() - 1);
            for (int i = 0; i < nx; i++) {
                int px = clamp((int) (u0 + (i + 0.5) * (u1 - u0) / nx), 0, src.width() - 1);
                int c = src.argb(px, py);
                int a = c >>> 24;
                sa += a;
                sr += (long) ((c >> 16) & 255) * a;
                sg += (long) ((c >> 8) & 255) * a;
                sb += (long) (c & 255) * a;
            }
        }
        if (sa == 0) {
            return 0;
        }
        int n = nx * ny;
        return ((int) (sa / n) << 24) | ((int) (sr / sa) << 16) | ((int) (sg / sa) << 8) | (int) (sb / sa);
    }

    private static int average(Pixels src) {
        long r = 0;
        long g = 0;
        long b = 0;
        int n = 0;
        for (int j = 0; j < 16; j++) {
            for (int i = 0; i < 16; i++) {
                int c = flatten(sample(src,
                        (double) i * src.width() / 16, (double) j * src.height() / 16,
                        (double) (i + 1) * src.width() / 16, (double) (j + 1) * src.height() / 16), BLUE);
                r += (c >> 16) & 255;
                g += (c >> 8) & 255;
                b += c & 255;
                n++;
            }
        }
        return 0xFF000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
    }

    /** Lays a (semi-)transparent colour over a solid background. */
    static int flatten(int c, int bg) {
        int a = c >>> 24;
        if (a == 255) {
            return c;
        }
        int r = (((c >> 16) & 255) * a + ((bg >> 16) & 255) * (255 - a)) / 255;
        int g = (((c >> 8) & 255) * a + ((bg >> 8) & 255) * (255 - a)) / 255;
        int b = ((c & 255) * a + (bg & 255) * (255 - a)) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int darken(int c, float f) {
        int r = (int) (((c >> 16) & 255) * f);
        int g = (int) (((c >> 8) & 255) * f);
        int b = (int) ((c & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
