# Blue Cape (Minecraft 1.21.11, Fabric)

A client-side cape mod. By default your player gets a flat blue cape (#1085EE).
You can also make the cape from a color code, from any photo on your phone, or from an
animated GIF, all inside the game.

**Offline friendly:** the mod has no login and no account check. It works the same on offline /
cracked accounts. Only you see the cape (other players would need the mod too).
The only time it uses the internet is when you paste a link to a picture: it downloads that one
file and sends nothing about you.

## Opening it

- The **Cape** button in the top-left corner of the title screen or the pause menu, or
- the **Blue Cape** button on Options > Skin Customization (next to Done).

Make sure **Cape** is ticked on the Skin Customization screen.

## The cape screen

It shows your cape and elytra (moving, if you use a GIF) and has four buttons:

- **Photo or GIF** - a list of your newest pictures. Tap one and it becomes your cape.
  GIFs have a `[GIF]` tag.
  - **Show: All files / GIFs only** - switch the list to show only GIFs (it also looks for new files again).
  - **Path or link box, Paste and Use** - paste the path of a file, or a link to a picture or GIF, then press
    **Use**. **Paste** takes the text you copied (a GIF link or a file path) and uses it right away.
    Use the direct link to the file (it usually ends in `.gif`); a link to a web page will not work.
    A downloaded file is saved in `config/bluecape/photos` as `pasted_...`, so it shows in the list next time.
  - **Whole photo: ON/OFF** - OFF crops the picture to fill the cape, ON fits the whole picture.
  - **Cape file: ON/OFF** - ON if the image already is a cape texture (2:1, like 64x32 or 512x256).
  - **Quality: Normal / High / 4K** - how sharp the cape is (see below). It redoes the cape that is on now.
- **Palette** - make a cape from a palette. Tap **Palette** to switch between Basic, Pastel, Neon, Earth,
  Ocean and Sunset. Tap **Style** to switch between Solid, Fade (top to bottom), Stripes, Bands (across),
  Checkers and Border. Tap **Color 1** / **Color 2** to choose which color you are setting, then tap a color.
  The little cape on the right shows the result; press **Apply** to use it. The elytra gets the average color.
- **Color code** - type a color code like `1085EE` (also `#1085EE` or short `18E`) and press **Apply**.
- **Back to blue** - the plain blue cape again.

The list shows pictures from `DCIM/Camera`, `DCIM`, `Pictures`, `Pictures/Screenshots`,
`Download` on your phone, `.minecraft/screenshots`, and `config/bluecape/photos`.
If your launcher can't read your phone's gallery folders, copy files into
`config/bluecape/photos` and press the **Show** button to look again.

## Quality (up to 4K)

| Quality | Photo cape | GIF cape (each frame) |
| --- | --- | --- |
| Normal | 512 x 256 | 256 x 128 |
| High | 1024 x 512 | up to 1024 x 512 |
| 4K (default) | 4096 x 2048 | as big as the game's memory allows for that many frames |

A GIF has many frames and every frame is a picture, so a long GIF cannot be 4K: the mod picks the biggest
size that fits in memory and tells you the size it used. A bigger texture is sharper close up, but the game
does not smooth far-away capes, so they can look a little sparkly. Switch to High or Normal if you see that
or if the game gets slow.

## Cape colors

The back of the cape, its sides and the edges of the elytra wings take the **background color** of your
picture (the most common color along its edge). A black cat on a white background gets white sides, not grey.

## GIF capes

An animated GIF plays on your cape, and the elytra follows it. A GIF that does not move is treated like a photo.

- GIFs with more than 100 frames lose frames evenly, the speed stays the same.
- Biggest GIF: 40 MB and 8 megapixels.
- The GIF is copied to `config/bluecape/cape.gif`, so it is still there next launch.

## Elytra

The elytra keeps the game's own wing shape. The **Elytra** button next to **Done** on the cape screen switches
what the wings look like:

- **Elytra: Picture** (default) - your photo, GIF or palette is painted on the wings, like on the cape.
- **Elytra: Feathers** - the game's own elytra (feathers and shading), tinted to the color of your cape:
  the color code you applied, or the average color of your picture (of the current frame, for a GIF).
  The see-through gaps of the wings are filled in, so it is solid.

A flat color (and the blue default) has no picture, so it always uses the tinted feathers.
With **Cape file: ON** the wings from your cape file are used.

Works with JPG, PNG, BMP, GIF, TGA. Not WebP or HEIC (take a screenshot of the picture instead).
Phone photos that are stored rotated come out the right way up.

The cape is remembered in `config/bluecape/cape.png` (or `cape.gif`).

## Building

Needs Java 21. With GitHub Actions: put this zip and `build.yml` (in `.github/workflows/`)
in a repo, run the workflow, and download the jar from the build artifacts.
