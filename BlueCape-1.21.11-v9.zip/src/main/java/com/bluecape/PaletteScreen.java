package com.bluecape;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * Make a cape from a palette: pick a palette, a style, and one or two colors.
 * The little cape on the right shows how it will look before you press Apply.
 */
public class PaletteScreen extends Screen {
    private static final int COLS = 6;
    private static final int CONTROLS_W = 200;

    private final CapeScreen parent;
    private int palette = Math.min(CapeSettings.palette, Palettes.NAMES.length - 1);
    private CapeComposer.Pattern pattern = CapeSettings.pattern;
    private int color1 = CapeSettings.color1;
    private int color2 = CapeSettings.color2;
    private int slot = 1;                         // which color a tap on a swatch changes (1 or 2)
    private int[] previewColors;
    private ButtonWidget paletteButton;
    private ButtonWidget styleButton;
    private ButtonWidget slot1Button;
    private ButtonWidget slot2Button;
    private boolean showPreview;
    private int left;
    private int top = 34;

    public PaletteScreen(CapeScreen parent) {
        super(Text.literal("Palette"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        this.showPreview = this.width >= 270;
        int totalW = showPreview ? CONTROLS_W + 12 + 46 : CONTROLS_W;
        this.left = (this.width - totalW) / 2;

        paletteButton = this.addDrawableChild(ButtonWidget.builder(paletteLabel(), button -> {
            palette = (palette + 1) % Palettes.NAMES.length;
            button.setMessage(paletteLabel());
        }).dimensions(left, top, 98, 20).build());
        styleButton = this.addDrawableChild(ButtonWidget.builder(styleLabel(), button -> {
            pattern = pattern.next();
            if (pattern == CapeComposer.Pattern.SOLID) {
                slot = 1;
            }
            button.setMessage(styleLabel());
            refresh();
        }).dimensions(left + 102, top, 98, 20).build());

        slot1Button = this.addDrawableChild(ButtonWidget.builder(slotLabel(1), button -> {
            slot = 1;
            refresh();
        }).dimensions(left, top + 24, 98, 20).build());
        slot2Button = this.addDrawableChild(ButtonWidget.builder(slotLabel(2), button -> {
            slot = 2;
            refresh();
        }).dimensions(left + 102, top + 24, 98, 20).build());

        for (int i = 0; i < 12; i++) {
            final int index = i;
            int x = left + (i % COLS) * 34;
            int y = top + 52 + (i / COLS) * 24;
            this.addDrawableChild(ButtonWidget.builder(Text.empty(), button -> pickColor(index))
                    .dimensions(x, y, 30, 20).build());
        }

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Apply"), button -> apply())
                .dimensions(left, top + 104, 98, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Back"), button -> this.close())
                .dimensions(left + 102, top + 104, 98, 20).build());
        refresh();
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    private Text paletteLabel() {
        return Text.literal("Palette: " + Palettes.NAMES[palette]);
    }

    private Text styleLabel() {
        return Text.literal("Style: " + pattern.label);
    }

    private Text slotLabel(int which) {
        return Text.literal(slot == which ? "[Color " + which + "]" : "Color " + which);
    }

    private void pickColor(int index) {
        int rgb = Palettes.COLORS[palette][index];
        if (slot == 1) {
            color1 = rgb;
            if (pattern != CapeComposer.Pattern.SOLID) {
                slot = 2;                              // next tap picks the second color
            }
        } else {
            color2 = rgb;
        }
        refresh();
    }

    /** Updates the labels and the little preview after anything changed. */
    private void refresh() {
        slot1Button.setMessage(slotLabel(1));
        slot2Button.setMessage(slotLabel(2));
        slot2Button.active = pattern != CapeComposer.Pattern.SOLID;
        int[] px = CapeComposer.pattern(pattern, color1, color2, 2);       // 128 x 64
        previewColors = CapeComposer.capePreview(px, 128, 64);
    }

    private void apply() {
        CapeSettings.palette = palette;
        CapeSettings.pattern = pattern;
        CapeSettings.color1 = color1;
        CapeSettings.color2 = color2;
        CapeManager.usePattern(pattern, color1, color2);
        parent.setStatus("Palette cape applied!");
        this.client.setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int cx = this.width / 2;
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, 8, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Pick a style and your colors"), cx, 21, 0xFFA0A0A0);

        // the colors of the palette, painted on top of their buttons
        for (int i = 0; i < 12; i++) {
            int x = left + (i % COLS) * 34;
            int y = top + 52 + (i / COLS) * 24;
            context.fill(x + 3, y + 3, x + 27, y + 17, 0xFF000000 | Palettes.COLORS[palette][i]);
        }
        // the two chosen colors, on the color buttons
        PreviewDraw.swatch(context, left + 98 - 20, top + 24 + 5, 14, 10, color1);
        if (pattern != CapeComposer.Pattern.SOLID) {
            PreviewDraw.swatch(context, left + 102 + 98 - 20, top + 24 + 5, 14, 10, color2);
        }

        if (showPreview) {
            int px = left + CONTROLS_W + 12 + 3;
            PreviewDraw.cape(context, px, top + 2, 2, previewColors);
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Preview"), px + 20, top + 72, 0xFFA0A0A0);
        }
    }
}
