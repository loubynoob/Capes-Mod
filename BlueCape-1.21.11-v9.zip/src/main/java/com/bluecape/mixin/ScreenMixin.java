package com.bluecape.mixin;

import com.bluecape.CapeScreen;
import net.minecraft.client.gui.Drawable;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds a "Blue Cape" button to Options > Skin Customization.
 * It hooks every screen when it opens (and when it is rebuilt after a window resize), but only
 * acts on the screen whose title is "options.skinCustomisation.title", so no other screen is touched.
 */
@Mixin(Screen.class)
public abstract class ScreenMixin {
    @Shadow
    protected abstract <T extends Element & Drawable & Selectable> T addDrawableChild(T drawableElement);

    // In 1.21.11 the screen is opened with init(int width, int height).
    // require = 0: if a future game version changes this, the button is simply missing.
    @Inject(method = "init(II)V", at = @At("TAIL"), require = 0)
    private void bluecape$afterInit(int width, int height, CallbackInfo ci) {
        bluecape$addSkinScreenButton();
    }

    // After a window resize the screen is rebuilt: the widgets are cleared and init() runs again.
    @Inject(method = "clearAndInit", at = @At("TAIL"), require = 0)
    private void bluecape$afterRebuild(CallbackInfo ci) {
        bluecape$addSkinScreenButton();
    }

    private void bluecape$addSkinScreenButton() {
        Screen self = (Screen) (Object) this;
        Text title = self.getTitle();
        if (!(title.getContent() instanceof TranslatableTextContent content)
                || !"options.skinCustomisation.title".equals(content.getKey())) {
            return;
        }
        int buttonWidth = 70;
        int x = self.width / 2 + 104;            // right of the Done button
        int y = self.height - 27;
        if (x + buttonWidth > self.width - 4) {  // no room there (narrow screen): top-left corner instead
            x = 4;
            y = 4;
        }
        this.addDrawableChild(CapeScreen.openButton(self, x, y, buttonWidth, "Blue Cape"));
    }
}
