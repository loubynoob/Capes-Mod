package com.bluecape;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Tiny settings file: config/bluecape/settings.properties. Nothing here touches the network. */
final class CapeSettings {
    static CapeComposer.Fit fit = CapeComposer.Fit.FILL;
    static boolean readyMade = false;
    static String lastPath = "";
    static String colorHex = "#1085EE";
    /** Elytra colour as "#RRGGBB", "file" (use the elytra from a ready-made cape file), or "" (not saved yet). */
    static String elytra = "";
    /** Short description of the current cape, shown on the cape screen ("Default blue", "GIF: cat.gif", ...). */
    static String label = "";

    private CapeSettings() {
    }

    static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("bluecape");
    }

    static void load() {
        Path file = dir().resolve("settings.properties");
        if (!Files.isRegularFile(file)) {
            return;
        }
        try (InputStream in = Files.newInputStream(file)) {
            Properties p = new Properties();
            p.load(in);
            fit = "FIT".equals(p.getProperty("fit")) ? CapeComposer.Fit.FIT : CapeComposer.Fit.FILL;
            readyMade = "true".equals(p.getProperty("readyMade"));
            lastPath = p.getProperty("lastPath", "");
            colorHex = p.getProperty("colorHex", "#1085EE");
            elytra = p.getProperty("elytra", "");
            label = p.getProperty("label", "");
        } catch (IOException ignored) {
            // keep the defaults
        }
    }

    static void save() {
        try {
            Files.createDirectories(dir());
            Properties p = new Properties();
            p.setProperty("fit", fit.name());
            p.setProperty("readyMade", Boolean.toString(readyMade));
            p.setProperty("lastPath", lastPath);
            p.setProperty("colorHex", colorHex);
            p.setProperty("elytra", elytra);
            p.setProperty("label", label);
            try (OutputStream out = Files.newOutputStream(dir().resolve("settings.properties"))) {
                p.store(out, "Blue Cape settings");
            }
        } catch (IOException ignored) {
            // not fatal
        }
    }
}
