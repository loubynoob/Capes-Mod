package com.bluecape;

import java.util.Arrays;

/**
 * Builds the cape texture (512x256 = a 64x32 cape layout scaled up by 8).
 * Pure Java on purpose: it knows nothing about Minecraft, so it can be tested on its own.
 *
 * Cape layout in 64x32 units:
 *   outside of the cape  x=1..11,  y=1..17
 *   inside of the cape   x=12..22, y=1..17
 *   elytra wings         x=24..34 / x=36..46, y=2..22
 */
public final class CapeComposer {
    public static final int SCALE = 8;
    public static final int W = 64 * SCALE;
    public static final int H = 32 * SCALE;
    /** The blue from the screenshot (#1085EE). */
    public static final int BLUE = 0xFF1085EE;

    public enum Fit { FILL, FIT }

    /** Anything that can hand out ARGB pixels. */
    public interface Pixels {
        int width();

        int height();

        int argb(int x, int y);
    }

    private CapeComposer() {
    }

    /** The default cape: flat blue everywhere. (The elytra is the game's own elytra, tinted blue.) */
    public static int[] defaultCape() {
        return solid(BLUE);
    }

    /** A cape in one flat colour (0xRRGGBB). */
    public static int[] solid(int rgb) {
        int[] out = new int[W * H];
        Arrays.fill(out, 0xFF000000 | (rgb & 0xFFFFFF));
        return out;
    }

    /** The look of the outside of the cape: one colour, or two colours in a pattern. */
    public enum Pattern {
        SOLID("Solid"), FADE("Fade"), STRIPES("Stripes"), BANDS("Bands"), CHECKERS("Checkers"), BORDER("Border");

        public final String label;

        Pattern(String label) {
            this.label = label;
        }

        public Pattern next() {
            Pattern[] all = values();
            return all[(ordinal() + 1) % all.length];
        }
    }

    /**
     * A cape made of one or two colours (0xRRGGBB) in a pattern: 64*scale x 32*scale pixels.
     * SOLID uses only rgb1. FADE goes from rgb1 at the top to rgb2 at the bottom, STRIPES are upright,
     * BANDS are across, CHECKERS is a chessboard, BORDER has a rim of rgb2 around rgb1.
     */
    public static int[] pattern(Pattern pattern, int rgb1, int rgb2, int scale) {
        int w = 64 * scale;
        int[] out = new int[w * 32 * scale];
        int c1 = 0xFF000000 | (rgb1 & 0xFFFFFF);
        int c2 = 0xFF000000 | (rgb2 & 0xFFFFFF);
        // edges and top of the cape box: the middle colour
        Arrays.fill(out, pattern == Pattern.SOLID ? c1 : mix(c1, c2, 0.5f));
        // the inside of the cape (the back): a darker copy
        paintFace(out, scale, 12, 1, pattern, darken(c1, 0.8f), darken(c2, 0.8f));
        // the outside
        paintFace(out, scale, 1, 1, pattern, c1, c2);
        return out;
    }

    /** Paints one 10x16-unit face of the cape texture. */
    private static void paintFace(int[] out, int scale, int ux, int uy, Pattern pattern, int a, int b) {
        int w = 64 * scale;
        int fw = 10 * scale;
        int fh = 16 * scale;
        int stripe = 2 * scale;
        for (int y = 0; y < fh; y++) {
            for (int x = 0; x < fw; x++) {
                int color;
                switch (pattern) {
                    case FADE:
                        color = mix(a, b, (y + 0.5f) / fh);
                        break;
                    case STRIPES:
                        color = (x / stripe) % 2 == 0 ? a : b;
                        break;
                    case BANDS:
                        color = (y / stripe) % 2 == 0 ? a : b;
                        break;
                    case CHECKERS:
                        color = ((x / stripe) + (y / stripe)) % 2 == 0 ? a : b;
                        break;
                    case BORDER:
                        color = (x < scale || y < scale || x >= fw - scale || y >= fh - scale) ? b : a;
                        break;
                    default:
                        color = a;
                        break;
                }
                out[(uy * scale + y) * w + ux * scale + x] = color;
            }
        }
    }

    /** Straight blend of two ARGB colours (t = 0 gives a, t = 1 gives b), result is opaque. */
    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t + 0.5f);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t + 0.5f);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t + 0.5f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    /**
     * Tints the game's own elytra texture to one colour (0xRRGGBB). The feathers, the shading and
     * the see-through parts stay exactly as in the vanilla elytra, only the colour changes.
     * Returns ARGB pixels, same size as the source.
     */
    public static int[] recolorElytra(Pixels src, int rgb) {
        int w = src.width();
        int h = src.height();
        // the target colour as hue / saturation / lightness
        double r0 = ((rgb >> 16) & 0xFF) / 255.0;
        double g0 = ((rgb >> 8) & 0xFF) / 255.0;
        double b0 = (rgb & 0xFF) / 255.0;
        double max = Math.max(r0, Math.max(g0, b0));
        double min = Math.min(r0, Math.min(g0, b0));
        double light = (max + min) / 2;
        double sat = max == min ? 0 : (max - min) / (1 - Math.abs(2 * light - 1));
        double hue;
        if (max == min) {
            hue = 0;
        } else if (max == r0) {
            hue = ((g0 - b0) / (max - min) + 6) % 6;
        } else if (max == g0) {
            hue = (b0 - r0) / (max - min) + 2;
        } else {
            hue = (r0 - g0) / (max - min) + 4;
        }

        double sum = 0;
        long count = 0;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int c = src.argb(x, y);
                if ((c >>> 24) != 0) {
                    sum += luma(c);
                    count++;
                }
            }
        }
        double mean = count == 0 ? 0.5 : Math.max(0.05, sum / count);
        int[] out = new int[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int c = src.argb(x, y);
                int a = c >>> 24;
                if (a == 0) {
                    out[y * w + x] = 0;
                    continue;
                }
                // how much lighter or darker than the average pixel this one is: that shading is kept
                double f = luma(c) / mean;
                double l = f <= 1 ? light * f : light + (1 - light) * Math.min(1.0, (f - 1) * 0.6);
                out[y * w + x] = (a << 24) | hslToRgb(hue, sat, l);
            }
        }
        return out;
    }

    private static int hslToRgb(double hue, double sat, double light) {
        double c = (1 - Math.abs(2 * light - 1)) * sat;
        double hp = hue % 6;
        double x = c * (1 - Math.abs(hp % 2 - 1));
        double r = 0;
        double g = 0;
        double b = 0;
        if (hp < 1) {
            r = c;
            g = x;
        } else if (hp < 2) {
            r = x;
            g = c;
        } else if (hp < 3) {
            g = c;
            b = x;
        } else if (hp < 4) {
            g = x;
            b = c;
        } else if (hp < 5) {
            r = x;
            b = c;
        } else {
            r = c;
            b = x;
        }
        double m = light - c / 2;
        int ri = clamp((int) Math.round((r + m) * 255), 0, 255);
        int gi = clamp((int) Math.round((g + m) * 255), 0, 255);
        int bi = clamp((int) Math.round((b + m) * 255), 0, 255);
        return (ri << 16) | (gi << 8) | bi;
    }

    /**
     * Fills the see-through gaps of the elytra wings, so no pixel is missing. Only the part of the
     * texture the elytra model uses (x 22..46, y 0..22 on a 64x32 texture) is touched: every gap
     * pixel takes the colour of the nearest wing pixel, so the feather lines simply carry on.
     * The pixels are changed in place (ARGB, width w, height h).
     */
    public static void fillElytraGaps(int[] px, int w, int h) {
        int s = Math.max(1, w / 64);
        int x0 = 22 * s;
        int x1 = Math.min(w, 46 * s);
        int y0 = 0;
        int y1 = Math.min(h, 22 * s);
        int rw = x1 - x0;
        int rh = y1 - y0;
        if (rw <= 0 || rh <= 0) {
            return;
        }
        boolean[] done = new boolean[rw * rh];
        int[] queue = new int[rw * rh];
        int head = 0;
        int tail = 0;
        for (int y = 0; y < rh; y++) {
            for (int x = 0; x < rw; x++) {
                int c = px[(y0 + y) * w + x0 + x];
                if ((c >>> 24) >= 26) {                    // drawn by the game (it hides alpha below 10%)
                    px[(y0 + y) * w + x0 + x] = c | 0xFF000000;
                    done[y * rw + x] = true;
                    queue[tail++] = y * rw + x;
                }
            }
        }
        int[] dx = {1, -1, 0, 0};
        int[] dy = {0, 0, 1, -1};
        while (head < tail) {
            int i = queue[head++];
            int cx = i % rw;
            int cy = i / rw;
            int color = px[(y0 + cy) * w + x0 + cx];
            for (int k = 0; k < 4; k++) {
                int nx = cx + dx[k];
                int ny = cy + dy[k];
                if (nx < 0 || ny < 0 || nx >= rw || ny >= rh || done[ny * rw + nx]) {
                    continue;
                }
                done[ny * rw + nx] = true;
                px[(y0 + ny) * w + x0 + nx] = color;
                queue[tail++] = ny * rw + nx;
            }
        }
    }

    private static double luma(int argb) {
        int r = (argb >> 16) & 0xFF;
        int g = (argb >> 8) & 0xFF;
        int b = argb & 0xFF;
        return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0;
    }

    /** The average colour (0xRRGGBB) of the outside of the cape in a cape texture made by this class. */
    public static int averageColor(int[] cape) {
        return averageColor(cape, SCALE);
    }

    /** Same, for a cape texture made at another scale (pixels per cape unit). */
    public static int averageColor(int[] cape, int scale) {
        int stride = 64 * scale;
        long r = 0;
        long g = 0;
        long b = 0;
        long n = 0;
        for (int y = 1 * scale; y < 17 * scale; y++) {
            for (int x = 1 * scale; x < 11 * scale; x++) {
                int c = cape[y * stride + x];
                if ((c >>> 24) != 0) {
                    r += (c >> 16) & 0xFF;
                    g += (c >> 8) & 0xFF;
                    b += c & 0xFF;
                    n++;
                }
            }
        }
        if (n == 0) {
            return BLUE & 0xFFFFFF;
        }
        return ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
    }

    /**
     * Reads a colour code like "#1085EE", "1085ee", "0x1085EE" or the short "18E".
     * Returns 0xRRGGBB, or -1 when the text is not a colour code.
     */
    public static int parseHex(String text) {
        if (text == null) {
            return -1;
        }
        String s = text.trim();
        if (s.startsWith("#")) {
            s = s.substring(1);
        } else if (s.startsWith("0x") || s.startsWith("0X")) {
            s = s.substring(2);
        }
        if (s.length() != 3 && s.length() != 6) {
            return -1;
        }
        int value = 0;
        for (int i = 0; i < s.length(); i++) {
            int digit = Character.digit(s.charAt(i), 16);
            if (digit < 0) {
                return -1;
            }
            value = value * 16 + digit;
        }
        if (s.length() == 3) {
            int r = (value >> 8) & 15;
            int g = (value >> 4) & 15;
            int b = value & 15;
            value = ((r * 17) << 16) | ((g * 17) << 8) | (b * 17);
        }
        return value;
    }

    /** Puts a photo on the outside of the cape (and on the elytra wings). */
    public static int[] fromPhoto(Pixels src, Fit fit) {
        return fromPhoto(src, fit, SCALE);
    }

    /** Same, at another scale: 64*scale x 32*scale pixels (8 = the normal 512x256, 4 = 256x128 for GIF frames). */
    public static int[] fromPhoto(Pixels src, Fit fit, int scale) {
        int avg = average(src);
        int[] out = new int[64 * scale * 32 * scale];
        Arrays.fill(out, avg);
        fillRect(out, scale, 12, 1, 10, 16, darken(avg, 0.8f));
        blit(out, scale, src, 1, 1, 10, 16, fit);
        blit(out, scale, src, 24, 2, 10, 20, fit);
        blit(out, scale, src, 36, 2, 10, 20, fit);
        return out;
    }

    /** Uses an image that already is a cape texture (64x32 style, or 46x22 old style). */
    public static int[] fromReadyMade(Pixels src) {
        return fromReadyMade(src, SCALE);
    }

    /** Same, at another scale (see fromPhoto). */
    public static int[] fromReadyMade(Pixels src, int scale) {
        final int W = 64 * scale;
        final int H = 32 * scale;
        int sw = src.width();
        int sh = src.height();
        double ratio = (double) sw / sh;
        double fw;
        if (Math.abs(ratio - 2.0) < 0.02) {
            fw = 64;
        } else if (Math.abs(ratio - 46.0 / 22.0) < 0.02) {
            fw = 46;
        } else {
            throw new IllegalArgumentException("A cape file must be 2:1 (like 64x32 or 512x256). This image is " + sw + "x" + sh + ".");
        }
        double k = sw / fw; // source pixels per cape unit
        int[] out = new int[W * H];
        for (int y = 0; y < H; y++) {
            double v0 = y * (32.0 / H) * k;
            double v1 = (y + 1) * (32.0 / H) * k;
            for (int x = 0; x < W; x++) {
                double u0 = x * (64.0 / W) * k;
                double u1 = (x + 1) * (64.0 / W) * k;
                if (u0 >= sw || v0 >= sh) {
                    out[y * W + x] = BLUE;
                } else {
                    out[y * W + x] = sample(src, u0, v0, Math.min(u1, sw), Math.min(v1, sh));
                }
            }
        }
        return out;
    }

    /** Wraps pixels so a phone photo with an EXIF rotation tag comes out the right way up. */
    public static Pixels oriented(Pixels raw, int orientation) {
        if (orientation < 2 || orientation > 8) {
            return raw;
        }
        final int sw = raw.width();
        final int sh = raw.height();
        final boolean swap = orientation >= 5;
        return new Pixels() {
            @Override
            public int width() {
                return swap ? sh : sw;
            }

            @Override
            public int height() {
                return swap ? sw : sh;
            }

            @Override
            public int argb(int x, int y) {
                switch (orientation) {
                    case 2:
                        return raw.argb(sw - 1 - x, y);
                    case 3:
                        return raw.argb(sw - 1 - x, sh - 1 - y);
                    case 4:
                        return raw.argb(x, sh - 1 - y);
                    case 5:
                        return raw.argb(y, x);
                    case 6:
                        return raw.argb(y, sh - 1 - x);
                    case 7:
                        return raw.argb(sw - 1 - y, sh - 1 - x);
                    default: // 8
                        return raw.argb(sw - 1 - y, x);
                }
            }
        };
    }

    /** Reads the EXIF orientation (1..8) from JPEG bytes; 1 when there is none. */
    public static int exifOrientation(byte[] d) {
        if (d.length < 4 || (d[0] & 0xFF) != 0xFF || (d[1] & 0xFF) != 0xD8) {
            return 1;
        }
        int p = 2;
        while (p + 4 <= d.length) {
            if ((d[p] & 0xFF) != 0xFF) {
                return 1;
            }
            int marker = d[p + 1] & 0xFF;
            if (marker == 0xD8 || marker == 0x01 || (marker >= 0xD0 && marker <= 0xD7)) {
                p += 2;
                continue;
            }
            if (marker == 0xDA || marker == 0xD9) {
                return 1;
            }
            int len = ((d[p + 2] & 0xFF) << 8) | (d[p + 3] & 0xFF);
            if (marker == 0xE1 && len >= 8 && p + 10 <= d.length
                    && d[p + 4] == 'E' && d[p + 5] == 'x' && d[p + 6] == 'i' && d[p + 7] == 'f'
                    && d[p + 8] == 0 && d[p + 9] == 0) {
                return tiffOrientation(d, p + 10, Math.min(d.length, p + 2 + len));
            }
            p += 2 + len;
        }
        return 1;
    }

    private static int tiffOrientation(byte[] d, int base, int end) {
        if (base + 8 > end) {
            return 1;
        }
        boolean le;
        if (d[base] == 'I' && d[base + 1] == 'I') {
            le = true;
        } else if (d[base] == 'M' && d[base + 1] == 'M') {
            le = false;
        } else {
            return 1;
        }
        long ifdOffset = u32(d, base + 4, le);
        if (ifdOffset < 8 || base + ifdOffset + 2 > end) {
            return 1;
        }
        int ifd = (int) (base + ifdOffset);
        int count = u16(d, ifd, le);
        for (int i = 0; i < count; i++) {
            int e = ifd + 2 + i * 12;
            if (e + 12 > end) {
                break;
            }
            if (u16(d, e, le) == 0x0112) {
                int v = u16(d, e + 8, le);
                return (v >= 1 && v <= 8) ? v : 1;
            }
        }
        return 1;
    }

    private static int u16(byte[] d, int o, boolean le) {
        int a = d[o] & 0xFF;
        int b = d[o + 1] & 0xFF;
        return le ? (b << 8) | a : (a << 8) | b;
    }

    private static long u32(byte[] d, int o, boolean le) {
        long a = u16(d, o, le);
        long b = u16(d, o + 2, le);
        return le ? (b << 16) | a : (a << 16) | b;
    }

    // ---------------------------------------------------------------- small previews for the screen

    /** Cells across / down of the cape preview (the outside of the cape, half a cape unit per cell). */
    public static final int PREVIEW_W = 20;
    public static final int PREVIEW_H = 32;
    /** Cells of one wing preview. */
    public static final int WING_W = 10;
    public static final int WING_H = 20;

    /**
     * The outside of the cape as PREVIEW_W x PREVIEW_H colours (ARGB), for drawing on the screen.
     * px is a cape texture of any size that keeps the 64x32 layout (width w).
     */
    public static int[] capePreview(int[] px, int w, int h) {
        int[] out = new int[PREVIEW_W * PREVIEW_H];
        double unit = w / 64.0;
        for (int j = 0; j < PREVIEW_H; j++) {
            for (int i = 0; i < PREVIEW_W; i++) {
                double x0 = (1 + i * 0.5) * unit;
                double y0 = (1 + j * 0.5) * unit;
                out[j * PREVIEW_W + i] = boxAverage(px, w, h, x0, y0, x0 + 0.5 * unit, y0 + 0.5 * unit);
            }
        }
        return out;
    }

    /** One wing (the outer wing face of an elytra texture, 10x20 units) as WING_W x WING_H colours. */
    public static int[] wingPreview(int[] px, int w, int h) {
        int[] out = new int[WING_W * WING_H];
        double unit = w / 64.0;
        for (int j = 0; j < WING_H; j++) {
            for (int i = 0; i < WING_W; i++) {
                double x0 = (36 + i) * unit;
                double y0 = (2 + j) * unit;
                out[j * WING_W + i] = boxAverage(px, w, h, x0, y0, x0 + unit, y0 + unit);
            }
        }
        return out;
    }

    /** Average colour of a rectangle of a pixel array, alpha-aware; 0 when it is all transparent. */
    private static int boxAverage(int[] px, int w, int h, double x0, double y0, double x1, double y1) {
        int ix0 = clamp((int) Math.floor(x0), 0, w - 1);
        int iy0 = clamp((int) Math.floor(y0), 0, h - 1);
        int ix1 = clamp((int) Math.ceil(x1) - 1, ix0, w - 1);
        int iy1 = clamp((int) Math.ceil(y1) - 1, iy0, h - 1);
        long sa = 0;
        long sr = 0;
        long sg = 0;
        long sb = 0;
        int n = 0;
        for (int y = iy0; y <= iy1; y++) {
            for (int x = ix0; x <= ix1; x++) {
                int c = px[y * w + x];
                int a = c >>> 24;
                sa += a;
                sr += (long) ((c >> 16) & 255) * a;
                sg += (long) ((c >> 8) & 255) * a;
                sb += (long) (c & 255) * a;
                n++;
            }
        }
        if (sa == 0) {
            return 0;
        }
        return ((int) (sa / n) << 24) | ((int) (sr / sa) << 16) | ((int) (sg / sa) << 8) | (int) (sb / sa);
    }

    // ---------------------------------------------------------------- drawing helpers

    private static void blit(int[] out, int scale, Pixels src, int ux, int uy, int uw, int uh, Fit fit) {
        final int W = 64 * scale;
        int rx = ux * scale;
        int ry = uy * scale;
        int rw = uw * scale;
        int rh = uh * scale;
        int sw = src.width();
        int sh = src.height();
        double dstAspect = (double) rw / rh;
        double srcAspect = (double) sw / sh;
        double cx = 0;
        double cy = 0;
        double cw = sw;
        double ch = sh;
        int dx = 0;
        int dy = 0;
        int dw = rw;
        int dh = rh;
        if (fit == Fit.FILL) {
            if (srcAspect > dstAspect) {
                cw = sh * dstAspect;
                cx = (sw - cw) / 2;
            } else {
                ch = sw / dstAspect;
                cy = (sh - ch) / 2;
            }
        } else {
            if (srcAspect > dstAspect) {
                dh = Math.max(1, (int) Math.round(rw / srcAspect));
                dy = (rh - dh) / 2;
            } else {
                dw = Math.max(1, (int) Math.round(rh * srcAspect));
                dx = (rw - dw) / 2;
            }
        }
        for (int y = 0; y < dh; y++) {
            double v0 = cy + y * ch / dh;
            double v1 = cy + (y + 1) * ch / dh;
            for (int x = 0; x < dw; x++) {
                double u0 = cx + x * cw / dw;
                double u1 = cx + (x + 1) * cw / dw;
                out[(ry + dy + y) * W + rx + dx + x] = flatten(sample(src, u0, v0, u1, v1), BLUE);
            }
        }
    }

    private static void fillRect(int[] out, int scale, int ux, int uy, int uw, int uh, int color) {
        final int W = 64 * scale;
        for (int y = uy * scale; y < (uy + uh) * scale; y++) {
            for (int x = ux * scale; x < (ux + uw) * scale; x++) {
                out[y * W + x] = color;
            }
        }
    }

    /** Average colour of a source rectangle (a few samples per output pixel, alpha-aware). */
    static int sample(Pixels src, double u0, double v0, double u1, double v1) {
        int nx = clamp((int) Math.ceil(u1 - u0), 1, 4);
        int ny = clamp((int) Math.ceil(v1 - v0), 1, 4);
        long sa = 0;
        long sr = 0;
        long sg = 0;
        long sb = 0;
        for (int j = 0; j < ny; j++) {
            int py = clamp((int) (v0 + (j + 0.5) * (v1 - v0) / ny), 0, src.height() - 1);
            for (int i = 0; i < nx; i++) {
                int px = clamp((int) (u0 + (i + 0.5) * (u1 - u0) / nx), 0, src.width() - 1);
                int c = src.argb(px, py);
                int a = c >>> 24;
                sa += a;
                sr += (long) ((c >> 16) & 255) * a;
                sg += (long) ((c >> 8) & 255) * a;
                sb += (long) (c & 255) * a;
            }
        }
        if (sa == 0) {
            return 0;
        }
        int n = nx * ny;
        return ((int) (sa / n) << 24) | ((int) (sr / sa) << 16) | ((int) (sg / sa) << 8) | (int) (sb / sa);
    }

    private static int average(Pixels src) {
        long r = 0;
        long g = 0;
        long b = 0;
        int n = 0;
        for (int j = 0; j < 16; j++) {
            for (int i = 0; i < 16; i++) {
                int c = flatten(sample(src,
                        (double) i * src.width() / 16, (double) j * src.height() / 16,
                        (double) (i + 1) * src.width() / 16, (double) (j + 1) * src.height() / 16), BLUE);
                r += (c >> 16) & 255;
                g += (c >> 8) & 255;
                b += c & 255;
                n++;
            }
        }
        return 0xFF000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
    }

    /** Lays a (semi-)transparent colour over a solid background. */
    static int flatten(int c, int bg) {
        int a = c >>> 24;
        if (a == 255) {
            return c;
        }
        int r = (((c >> 16) & 255) * a + ((bg >> 16) & 255) * (255 - a)) / 255;
        int g = (((c >> 8) & 255) * a + ((bg >> 8) & 255) * (255 - a)) / 255;
        int b = ((c & 255) * a + (bg & 255) * (255 - a)) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int darken(int c, float f) {
        int r = (int) (((c >> 16) & 255) * f);
        int g = (int) (((c >> 8) & 255) * f);
        int b = (int) ((c & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
