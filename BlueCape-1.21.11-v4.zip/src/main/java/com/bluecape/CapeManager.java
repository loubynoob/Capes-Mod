package com.bluecape;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.AssetInfo;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.AccessDeniedException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Owns the cape texture. Everything is local: files in, texture out.
 * There is no login, no session check and no network access anywhere in this mod,
 * so it behaves the same for offline / cracked accounts.
 */
public final class CapeManager {
    private static final Logger LOG = LoggerFactory.getLogger("bluecape");
    private static final Executor WORKER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "bluecape-worker");
        t.setDaemon(true);
        return t;
    });

    private static boolean initialized;
    private static int counter;
    private static Identifier currentId;
    private static Identifier currentElytraId;
    private static AssetInfo.TextureAsset asset;
    private static AssetInfo.TextureAsset elytraAsset;
    private static final String DEFAULT_ELYTRA = "#1085EE";

    private CapeManager() {
    }

    /** What the mixin hands to the renderer. Created lazily, on the render thread. */
    public static AssetInfo.TextureAsset get() {
        if (!initialized) {
            initialized = true;
            loadSavedOrDefault();
        }
        return asset;
    }

    /** The elytra texture: the game's own elytra, tinted. Created together with the cape texture. */
    public static AssetInfo.TextureAsset getElytra() {
        get();
        return elytraAsset;
    }

    private static void loadSavedOrDefault() {
        Path saved = CapeSettings.dir().resolve("cape.png");
        if (Files.isRegularFile(saved)) {
            try {
                NativeImage image = NativeImage.read(Files.readAllBytes(saved));
                String elytra = CapeSettings.elytra;
                if (elytra.isEmpty()) {
                    // older save without an elytra colour: use the average colour of the saved cape
                    elytra = String.format("#%06X", CapeComposer.averageColor(pixelsOf(image)));
                }
                install(image, elytra);
                return;
            } catch (Exception e) {
                LOG.warn("Could not load saved cape, using the default blue one", e);
            }
        }
        install(toImage(CapeComposer.defaultCape()), DEFAULT_ELYTRA);
    }

    /** Back to the plain blue cape. */
    public static void useDefault() {
        initialized = true;
        install(toImage(CapeComposer.defaultCape()), DEFAULT_ELYTRA);
        try {
            Files.deleteIfExists(CapeSettings.dir().resolve("cape.png"));
        } catch (IOException ignored) {
            // not fatal
        }
        CapeSettings.lastPath = "";
        CapeSettings.elytra = DEFAULT_ELYTRA;
        CapeSettings.save();
    }

    /** A flat cape in one colour (0xRRGGBB), saved so it is still there next launch. */
    public static void useColor(int rgb) {
        initialized = true;
        NativeImage image = toImage(CapeComposer.solid(rgb));
        try {
            Files.createDirectories(CapeSettings.dir());
            image.writeTo(CapeSettings.dir().resolve("cape.png"));
        } catch (IOException e) {
            LOG.warn("Could not save cape.png (the cape still works this session)", e);
        }
        String hex = String.format("#%06X", rgb & 0xFFFFFF);
        install(image, hex);
        CapeSettings.lastPath = "";
        CapeSettings.elytra = hex;
        CapeSettings.save();
    }

    /**
     * Turns an image file into the cape. Reading and scaling happen on a worker thread,
     * the texture upload happens on the game thread. The future completes with a short
     * message for the screen, on the game thread.
     */
    public static CompletableFuture<String> importFile(Path file) {
        final CapeComposer.Fit fit = CapeSettings.fit;
        final boolean readyMade = CapeSettings.readyMade;
        final CompletableFuture<String> result = new CompletableFuture<>();

        CompletableFuture.supplyAsync(() -> {
            try {
                byte[] data = Files.readAllBytes(file);
                int orientation = CapeComposer.exifOrientation(data);
                try (NativeImage src = NativeImage.read(data)) {
                    CapeComposer.Pixels raw = new CapeComposer.Pixels() {
                        @Override
                        public int width() {
                            return src.getWidth();
                        }

                        @Override
                        public int height() {
                            return src.getHeight();
                        }

                        @Override
                        public int argb(int x, int y) {
                            return src.getColorArgb(x, y);
                        }
                    };
                    int[] pixels = readyMade
                            ? CapeComposer.fromReadyMade(raw)
                            : CapeComposer.fromPhoto(CapeComposer.oriented(raw, orientation), fit);
                    String elytraSpec = readyMade
                            ? "file"
                            : String.format("#%06X", CapeComposer.averageColor(pixels));
                    NativeImage out = toImage(pixels);
                    try {
                        Files.createDirectories(CapeSettings.dir());
                        out.writeTo(CapeSettings.dir().resolve("cape.png"));
                    } catch (IOException e) {
                        LOG.warn("Could not save cape.png (the cape still works this session)", e);
                    }
                    return new Imported(out, elytraSpec);
                }
            } catch (IOException e) {
                throw new CompletionException(e);
            }
        }, WORKER).whenComplete((imported, error) -> MinecraftClient.getInstance().execute(() -> {
            if (error != null) {
                result.complete(describe(error));
                return;
            }
            initialized = true;
            install(imported.image(), imported.elytra());
            CapeSettings.elytra = imported.elytra();
            CapeSettings.save();
            result.complete("Cape applied!");
        }));

        return result;
    }

    /** A freshly made cape texture plus the elytra colour that goes with it. */
    private record Imported(NativeImage image, String elytra) {
    }

    private static String describe(Throwable error) {
        Throwable t = error;
        while (t instanceof CompletionException && t.getCause() != null) {
            t = t.getCause();
        }
        LOG.warn("Cape import failed", t);
        if (t instanceof NoSuchFileException) {
            return "File not found.";
        }
        if (t instanceof AccessDeniedException) {
            return "No permission to read that file. Copy it to config/bluecape/photos.";
        }
        if (t instanceof IllegalArgumentException) {
            return String.valueOf(t.getMessage());
        }
        if (t instanceof IOException) {
            return "Can't read that image. Use JPG, PNG, BMP or GIF (not WebP/HEIC).";
        }
        return "Failed: " + t;
    }

    private static NativeImage toImage(int[] pixels) {
        NativeImage image = new NativeImage(CapeComposer.W, CapeComposer.H, true);
        for (int y = 0; y < CapeComposer.H; y++) {
            for (int x = 0; x < CapeComposer.W; x++) {
                image.setColorArgb(x, y, pixels[y * CapeComposer.W + x]);
            }
        }
        return image;
    }

    private static int[] pixelsOf(NativeImage image) {
        int[] out = new int[image.getWidth() * image.getHeight()];
        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                out[y * image.getWidth() + x] = image.getColorArgb(x, y);
            }
        }
        return out;
    }

    /**
     * The game's own elytra texture (whatever the active resource packs say), tinted to one colour.
     * Returns null when the texture can't be found, then the cape texture is used for the elytra.
     */
    private static NativeImage tintedElytra(int rgb) {
        try {
            ResourceManager resources = MinecraftClient.getInstance().getResourceManager();
            Identifier found = null;
            for (Identifier id : resources.findResources("textures/entity", p -> p.getPath().endsWith("elytra.png")).keySet()) {
                if ("minecraft".equals(id.getNamespace()) && id.getPath().endsWith("/elytra.png")
                        && (found == null || id.getPath().length() < found.getPath().length())) {
                    found = id;
                }
            }
            if (found == null) {
                LOG.warn("Could not find the game's elytra texture, using the cape texture for the elytra");
                return null;
            }
            try (InputStream in = resources.open(found); NativeImage src = NativeImage.read(in)) {
                CapeComposer.Pixels pixels = new CapeComposer.Pixels() {
                    @Override
                    public int width() {
                        return src.getWidth();
                    }

                    @Override
                    public int height() {
                        return src.getHeight();
                    }

                    @Override
                    public int argb(int x, int y) {
                        return src.getColorArgb(x, y);
                    }
                };
                int[] tinted = CapeComposer.recolorElytra(pixels, rgb);
                NativeImage out = new NativeImage(src.getWidth(), src.getHeight(), true);
                for (int y = 0; y < src.getHeight(); y++) {
                    for (int x = 0; x < src.getWidth(); x++) {
                        out.setColorArgb(x, y, tinted[y * src.getWidth() + x]);
                    }
                }
                return out;
            }
        } catch (Exception e) {
            LOG.warn("Could not tint the elytra, using the cape texture for the elytra", e);
            return null;
        }
    }

    /**
     * Game thread only. Registers fresh textures and drops the previous ones.
     * elytraSpec is "#RRGGBB" (tint the game's elytra) or "file" (use the cape texture's own wings).
     */
    private static void install(NativeImage capeImage, String elytraSpec) {
        TextureManager textures = MinecraftClient.getInstance().getTextureManager();
        int n = ++counter;
        Identifier id = Identifier.of("bluecape", "cape_" + n);
        textures.registerTexture(id, new NativeImageBackedTexture(() -> "bluecape " + id, capeImage));
        asset = new AssetInfo.TextureAssetInfo(id, id);

        Identifier elytraId = null;
        NativeImage elytraImage = null;
        if (!"file".equals(elytraSpec)) {
            int rgb = CapeComposer.parseHex(elytraSpec);
            elytraImage = tintedElytra(rgb < 0 ? (CapeComposer.BLUE & 0xFFFFFF) : rgb);
        }
        if (elytraImage != null) {
            elytraId = Identifier.of("bluecape", "elytra_" + n);
            final Identifier registered = elytraId;
            textures.registerTexture(registered, new NativeImageBackedTexture(() -> "bluecape " + registered, elytraImage));
            elytraAsset = new AssetInfo.TextureAssetInfo(registered, registered);
        } else {
            elytraAsset = asset;
        }

        Identifier oldCape = currentId;
        Identifier oldElytra = currentElytraId;
        currentId = id;
        currentElytraId = elytraId;
        if (oldCape != null) {
            textures.destroyTexture(oldCape);
        }
        if (oldElytra != null) {
            textures.destroyTexture(oldElytra);
        }
    }
}
