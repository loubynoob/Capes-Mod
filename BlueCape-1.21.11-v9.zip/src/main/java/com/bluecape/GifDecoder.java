package com.bluecape;

import java.io.IOException;

/**
 * Reads GIF files, animated ones too, with no library at all (pure Java, nothing from Minecraft).
 * Every frame is handed out as a full picture: the sub-pictures, the transparent pixels and the
 * "what to do with the old frame" rules of the GIF format are already applied.
 */
public final class GifDecoder {
    /** Gets every finished frame, in order. The canvas array is reused: copy it if you keep it. */
    public interface Sink {
        /** canvas is ARGB, width*height pixels; 0 = fully transparent. */
        void frame(int index, int[] canvas, int width, int height, int delayMs) throws IOException;
    }

    /** Biggest picture accepted (width * height). */
    public static final int MAX_PIXELS = 8_000_000;

    private GifDecoder() {
    }

    public static boolean isGif(byte[] d) {
        return d.length >= 6 && d[0] == 'G' && d[1] == 'I' && d[2] == 'F' && d[3] == '8'
                && (d[4] == '7' || d[4] == '9') && d[5] == 'a';
    }

    /** How many frames the file has (quick, nothing is decoded). */
    public static int countFrames(byte[] data) throws IOException {
        return run(data, null);
    }

    /** Decodes every frame, calling the sink once per frame. Returns the number of frames. */
    public static int decode(byte[] data, Sink sink) throws IOException {
        return run(data, sink);
    }

    /** GIF delays are in 1/100 s; 0 and 1 mean "as fast as possible", which browsers show as 100 ms. */
    static int delayToMs(int centis) {
        return centis <= 1 ? 100 : centis * 10;
    }

    private static int run(byte[] d, Sink sink) throws IOException {
        if (!isGif(d)) {
            throw new IOException("Not a GIF file");
        }
        int p = 6;
        if (p + 7 > d.length) {
            throw new IOException("GIF is cut off");
        }
        int w = u16(d, p);
        int h = u16(d, p + 2);
        int packed = d[p + 4] & 0xFF;
        p += 7;
        if (w <= 0 || h <= 0) {
            throw new IOException("GIF has no size");
        }
        if ((long) w * h > MAX_PIXELS) {
            throw new IllegalArgumentException("This GIF is too big (" + w + "x" + h + "). Use one under 8 megapixels.");
        }
        int[] globalPalette = null;
        if ((packed & 0x80) != 0) {
            int n = 1 << ((packed & 7) + 1);
            if (p + n * 3 > d.length) {
                throw new IOException("GIF is cut off");
            }
            globalPalette = readPalette(d, p, n);
            p += n * 3;
        }

        int[] canvas = sink == null ? null : new int[w * h];
        int[] backup = null;
        int frames = 0;

        // settings from the "graphic control" block, they belong to the next picture only
        int disposal = 0;
        int delay = 0;
        int transparent = -1;
        // what the previous picture asked for
        int prevDisposal = 0;
        int prevX = 0;
        int prevY = 0;
        int prevW = 0;
        int prevH = 0;

        while (p < d.length) {
            int block = d[p++] & 0xFF;
            if (block == 0x3B) {                       // end of file
                break;
            }
            if (block == 0x21) {                       // extension
                if (p >= d.length) {
                    break;
                }
                int label = d[p++] & 0xFF;
                if (label == 0xF9 && p + 5 <= d.length && (d[p] & 0xFF) >= 4) {
                    int pk = d[p + 1] & 0xFF;
                    disposal = (pk >> 2) & 7;
                    delay = u16(d, p + 2);
                    transparent = (pk & 1) != 0 ? (d[p + 4] & 0xFF) : -1;
                }
                p = skipSubBlocks(d, p);
                continue;
            }
            if (block != 0x2C) {                       // not a picture: stop here, keep what we have
                break;
            }
            if (p + 9 > d.length) {
                break;
            }
            int ix = u16(d, p);
            int iy = u16(d, p + 2);
            int iw = u16(d, p + 4);
            int ih = u16(d, p + 6);
            int ipk = d[p + 8] & 0xFF;
            p += 9;
            int[] palette = globalPalette;
            if ((ipk & 0x80) != 0) {
                int n = 1 << ((ipk & 7) + 1);
                if (p + n * 3 > d.length) {
                    break;
                }
                palette = readPalette(d, p, n);
                p += n * 3;
            }
            boolean interlaced = (ipk & 0x40) != 0;
            if (p >= d.length) {
                break;
            }
            int minCode = d[p++] & 0xFF;
            int dataStart = p;
            p = skipSubBlocks(d, p);

            if (sink != null) {
                if (palette == null) {
                    throw new IOException("GIF has no colors");
                }
                // 1. undo what the previous picture asked for
                if (prevDisposal == 2) {
                    clearRect(canvas, w, h, prevX, prevY, prevW, prevH);
                } else if (prevDisposal == 3 && backup != null) {
                    System.arraycopy(backup, 0, canvas, 0, canvas.length);
                }
                // 2. remember the canvas if this picture wants it back afterwards
                if (disposal == 3) {
                    if (backup == null) {
                        backup = new int[canvas.length];
                    }
                    System.arraycopy(canvas, 0, backup, 0, canvas.length);
                }
                // 3. draw
                if ((long) iw * ih > MAX_PIXELS * 4L) {
                    throw new IllegalArgumentException("This GIF is too big.");
                }
                byte[] indices = lzw(d, dataStart, minCode, iw * ih);
                int[] rows = interlaced ? interlaceRows(ih) : null;
                for (int r = 0; r < ih; r++) {
                    int y = iy + (rows == null ? r : rows[r]);
                    if (y < 0 || y >= h) {
                        continue;
                    }
                    for (int c = 0; c < iw; c++) {
                        int x = ix + c;
                        if (x < 0 || x >= w) {
                            continue;
                        }
                        int index = indices[r * iw + c] & 0xFF;
                        if (index == transparent || index >= palette.length) {
                            continue;
                        }
                        canvas[y * w + x] = palette[index];
                    }
                }
                sink.frame(frames, canvas, w, h, delayToMs(delay));
            }
            frames++;
            prevDisposal = disposal;
            prevX = ix;
            prevY = iy;
            prevW = iw;
            prevH = ih;
            disposal = 0;
            delay = 0;
            transparent = -1;
        }
        if (frames == 0) {
            throw new IOException("No picture found in this GIF.");
        }
        return frames;
    }

    private static void clearRect(int[] canvas, int w, int h, int x0, int y0, int rw, int rh) {
        for (int y = Math.max(0, y0); y < Math.min(h, y0 + rh); y++) {
            for (int x = Math.max(0, x0); x < Math.min(w, x0 + rw); x++) {
                canvas[y * w + x] = 0;
            }
        }
    }

    /** For an interlaced picture: the row on the canvas for each row in the file. */
    private static int[] interlaceRows(int ih) {
        int[] map = new int[ih];
        int[] start = {0, 4, 2, 1};
        int[] step = {8, 8, 4, 2};
        int r = 0;
        for (int pass = 0; pass < 4; pass++) {
            for (int y = start[pass]; y < ih; y += step[pass]) {
                map[r++] = y;
            }
        }
        return map;
    }

    private static int[] readPalette(byte[] d, int p, int n) {
        int[] palette = new int[n];
        for (int i = 0; i < n; i++) {
            palette[i] = 0xFF000000 | ((d[p + i * 3] & 0xFF) << 16) | ((d[p + i * 3 + 1] & 0xFF) << 8) | (d[p + i * 3 + 2] & 0xFF);
        }
        return palette;
    }

    /** Moves past a run of data sub-blocks (ends with a block of length 0). Never goes past the end. */
    private static int skipSubBlocks(byte[] d, int p) {
        while (p < d.length) {
            int n = d[p++] & 0xFF;
            if (n == 0) {
                return p;
            }
            p += n;
        }
        return d.length;
    }

    private static int u16(byte[] d, int p) {
        return (d[p] & 0xFF) | ((d[p + 1] & 0xFF) << 8);
    }

    /** The GIF flavour of LZW. Missing or broken data just leaves the rest of the picture at index 0. */
    private static byte[] lzw(byte[] d, int start, int minCode, int pixels) throws IOException {
        if (minCode < 1 || minCode > 8) {
            throw new IOException("GIF picture data is broken");
        }
        byte[] out = new byte[Math.max(0, pixels)];
        int clear = 1 << minCode;
        int eoi = clear + 1;
        int next = clear + 2;
        int codeSize = minCode + 1;
        int codeMask = (1 << codeSize) - 1;
        short[] prefix = new short[4096];
        byte[] suffix = new byte[4096];
        byte[] stack = new byte[4097];
        for (int i = 0; i < clear; i++) {
            suffix[i] = (byte) i;
        }
        int old = -1;
        int first = 0;
        int outPos = 0;
        int bits = 0;
        int datum = 0;
        int pos = start;
        int blockLeft = 0;

        decoding:
        while (outPos < out.length) {
            while (bits < codeSize) {
                if (blockLeft == 0) {
                    if (pos >= d.length) {
                        break decoding;
                    }
                    blockLeft = d[pos++] & 0xFF;
                    if (blockLeft == 0) {               // end of the data
                        break decoding;
                    }
                    blockLeft = Math.min(blockLeft, d.length - pos);
                    if (blockLeft == 0) {
                        break decoding;
                    }
                }
                datum |= (d[pos++] & 0xFF) << bits;
                bits += 8;
                blockLeft--;
            }
            int code = datum & codeMask;
            datum >>>= codeSize;
            bits -= codeSize;

            if (code == clear) {
                codeSize = minCode + 1;
                codeMask = (1 << codeSize) - 1;
                next = clear + 2;
                old = -1;
                continue;
            }
            if (code == eoi) {
                break;
            }
            if (old == -1) {
                if (code >= clear) {
                    break;
                }
                out[outPos++] = suffix[code];
                old = code;
                first = code;
                continue;
            }
            int inCode = code;
            int sp = 0;
            if (code >= next) {
                if (code > next) {
                    break;                              // broken data
                }
                stack[sp++] = (byte) first;
                code = old;
            }
            while (code >= clear) {
                if (sp >= 4096) {
                    break decoding;
                }
                stack[sp++] = suffix[code];
                code = prefix[code];
            }
            first = suffix[code] & 0xFF;
            stack[sp++] = (byte) first;
            if (next < 4096) {
                prefix[next] = (short) old;
                suffix[next] = (byte) first;
                next++;
                if ((next & codeMask) == 0 && next < 4096) {
                    codeSize++;
                    codeMask = (1 << codeSize) - 1;
                }
            }
            old = inCode;
            while (sp > 0 && outPos < out.length) {
                out[outPos++] = stack[--sp];
            }
        }
        return out;
    }
}
