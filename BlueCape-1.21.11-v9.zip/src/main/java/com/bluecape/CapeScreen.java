package com.bluecape;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * The main cape screen. It shows your cape and elytra (moving, for a GIF) and has four big buttons:
 * pick a photo or GIF, pick a palette, type a color code, or go back to the blue cape.
 * A button next to Done switches the elytra between your cape picture and plain tinted feathers.
 */
public class CapeScreen extends Screen {
    private final Screen parent;
    private String status = "";
    private int cell = 3;
    private int boxX;
    private int boxY;
    private int boxW;
    private int boxH;

    public CapeScreen(Screen parent) {
        super(Text.literal("Blue Cape"));
        this.parent = parent;
    }

    /** The small "Cape" button the mixins add to the title screen and the pause menu. */
    public static ButtonWidget openButton(Screen current) {
        return openButton(current, 4, 4, 44, "Cape");
    }

    /** A button that opens the cape screen, at any place and size (used on the Skin Customization screen). */
    public static ButtonWidget openButton(Screen current, int x, int y, int width, String label) {
        return ButtonWidget.builder(Text.literal(label),
                        button -> MinecraftClient.getInstance().setScreen(new CapeScreen(current)))
                .dimensions(x, y, width, 20)
                .build();
    }

    /** Called by the other screens when they come back here. */
    void setStatus(String message) {
        this.status = message;
    }

    @Override
    protected void init() {
        boolean roomy = this.width >= 300 && this.height >= 230;
        this.cell = roomy ? 3 : 2;
        int capeW = CapeComposer.PREVIEW_W * cell;
        int capeH = CapeComposer.PREVIEW_H * cell;
        int wingsW = 2 * CapeComposer.WING_W * cell;
        int gap = 12;
        int pad = 8;
        this.boxW = pad + capeW + gap + wingsW + pad;
        this.boxH = pad + capeH + 22;
        int buttonW = roomy ? 118 : 100;
        int totalW = boxW + 10 + buttonW;
        int left = (this.width - totalW) / 2;
        this.boxX = left;
        this.boxY = 28;

        int bx = left + boxW + 10;
        int step = Math.min(28, (boxH - 20) / 3);           // four buttons share the height of the box
        int by = boxY + (boxH - (3 * step + 20)) / 2;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Photo or GIF"),
                button -> this.client.setScreen(new PhotoScreen(this)))
                .dimensions(bx, by, buttonW, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Palette"),
                button -> this.client.setScreen(new PaletteScreen(this)))
                .dimensions(bx, by + step, buttonW, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Color code"),
                button -> this.client.setScreen(new ColorScreen(this)))
                .dimensions(bx, by + 2 * step, buttonW, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Back to blue"), button -> {
            CapeManager.useDefault();
            status = "Back to the blue cape.";
        }).dimensions(bx, by + 3 * step, buttonW, 20).build());

        int doneY = Math.min(this.height - 28, boxY + boxH + 44);
        int rowW = Math.min(124, (this.width - 20 - 8) / 2);
        this.addDrawableChild(ButtonWidget.builder(elytraLabel(), button -> {
            CapeSettings.elytraPicture = !CapeSettings.elytraPicture;
            CapeSettings.save();
            button.setMessage(elytraLabel());
            if (!CapeManager.hasElytraPicture()) {
                status = "A flat color has no picture, so the elytra keeps its feathers.";
            } else {
                status = CapeSettings.elytraPicture
                        ? "The elytra now shows your cape picture."
                        : "The elytra now has plain feathers in your color.";
            }
        }).dimensions(this.width / 2 - rowW - 4, doneY, rowW, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> this.close())
                .dimensions(this.width / 2 + 4, doneY, rowW, 20).build());
    }

    private static Text elytraLabel() {
        return Text.literal(CapeSettings.elytraPicture ? "Elytra: Picture" : "Elytra: Feathers");
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int cx = this.width / 2;
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, 12, 0xFFFFFFFF);

        // the preview box
        context.fill(boxX, boxY, boxX + boxW, boxY + boxH, 0xAA000000);
        int capeW = CapeComposer.PREVIEW_W * cell;
        int capeH = CapeComposer.PREVIEW_H * cell;
        int wingsW = 2 * CapeComposer.WING_W * cell;
        int wingH = CapeComposer.WING_H * cell;
        int capeX = boxX + 8;
        int capeY = boxY + 8;
        int wingsX = capeX + capeW + 12;
        int wingsY = capeY + (capeH - wingH) / 2;
        PreviewDraw.cape(context, capeX, capeY, cell, CapeManager.capePreview());
        PreviewDraw.wings(context, wingsX, wingsY, cell, CapeManager.wingPreview());
        int labelY = capeY + capeH + 6;
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Cape"), capeX + capeW / 2, labelY, 0xFFA0A0A0);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Elytra"), wingsX + wingsW / 2, labelY, 0xFFA0A0A0);

        // what is on right now, and the last message
        int textY = boxY + boxH + 8;
        int maxW = this.width - 20;
        int next = PreviewDraw.textBlock(context, this.textRenderer, "Now: " + CapeManager.label(), cx, textY, maxW, 0xFFFFFFFF);
        PreviewDraw.textBlock(context, this.textRenderer, status, cx, next + 3, maxW, 0xFF7FD7FF);
    }
}
