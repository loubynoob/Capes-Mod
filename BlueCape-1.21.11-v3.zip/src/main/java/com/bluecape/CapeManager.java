package com.bluecape;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.util.AssetInfo;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Owns the cape texture. Everything is local: files in, texture out.
 * There is no login, no session check and no network access anywhere in this mod,
 * so it behaves the same for offline / cracked accounts.
 */
public final class CapeManager {
    private static final Logger LOG = LoggerFactory.getLogger("bluecape");
    private static final Executor WORKER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "bluecape-worker");
        t.setDaemon(true);
        return t;
    });

    private static boolean initialized;
    private static int counter;
    private static Identifier currentId;
    private static AssetInfo.TextureAsset asset;

    private CapeManager() {
    }

    /** What the mixin hands to the renderer. Created lazily, on the render thread. */
    public static AssetInfo.TextureAsset get() {
        if (!initialized) {
            initialized = true;
            loadSavedOrDefault();
        }
        return asset;
    }

    private static void loadSavedOrDefault() {
        Path saved = CapeSettings.dir().resolve("cape.png");
        if (Files.isRegularFile(saved)) {
            try {
                install(NativeImage.read(Files.readAllBytes(saved)));
                return;
            } catch (Exception e) {
                LOG.warn("Could not load saved cape, using the default blue one", e);
            }
        }
        install(toImage(CapeComposer.defaultCape()));
    }

    /** Back to the plain blue cape. */
    public static void useDefault() {
        initialized = true;
        install(toImage(CapeComposer.defaultCape()));
        try {
            Files.deleteIfExists(CapeSettings.dir().resolve("cape.png"));
        } catch (IOException ignored) {
            // not fatal
        }
        CapeSettings.lastPath = "";
        CapeSettings.save();
    }

    /** A flat cape in one colour (0xRRGGBB), saved so it is still there next launch. */
    public static void useColor(int rgb) {
        initialized = true;
        NativeImage image = toImage(CapeComposer.solid(rgb));
        try {
            Files.createDirectories(CapeSettings.dir());
            image.writeTo(CapeSettings.dir().resolve("cape.png"));
        } catch (IOException e) {
            LOG.warn("Could not save cape.png (the cape still works this session)", e);
        }
        install(image);
        CapeSettings.lastPath = "";
        CapeSettings.save();
    }

    /**
     * Turns an image file into the cape. Reading and scaling happen on a worker thread,
     * the texture upload happens on the game thread. The future completes with a short
     * message for the screen, on the game thread.
     */
    public static CompletableFuture<String> importFile(Path file) {
        final CapeComposer.Fit fit = CapeSettings.fit;
        final boolean readyMade = CapeSettings.readyMade;
        final CompletableFuture<String> result = new CompletableFuture<>();

        CompletableFuture.supplyAsync(() -> {
            try {
                byte[] data = Files.readAllBytes(file);
                int orientation = CapeComposer.exifOrientation(data);
                try (NativeImage src = NativeImage.read(data)) {
                    CapeComposer.Pixels raw = new CapeComposer.Pixels() {
                        @Override
                        public int width() {
                            return src.getWidth();
                        }

                        @Override
                        public int height() {
                            return src.getHeight();
                        }

                        @Override
                        public int argb(int x, int y) {
                            return src.getColorArgb(x, y);
                        }
                    };
                    int[] pixels = readyMade
                            ? CapeComposer.fromReadyMade(raw)
                            : CapeComposer.fromPhoto(CapeComposer.oriented(raw, orientation), fit);
                    NativeImage out = toImage(pixels);
                    try {
                        Files.createDirectories(CapeSettings.dir());
                        out.writeTo(CapeSettings.dir().resolve("cape.png"));
                    } catch (IOException e) {
                        LOG.warn("Could not save cape.png (the cape still works this session)", e);
                    }
                    return out;
                }
            } catch (IOException e) {
                throw new CompletionException(e);
            }
        }, WORKER).whenComplete((image, error) -> MinecraftClient.getInstance().execute(() -> {
            if (error != null) {
                result.complete(describe(error));
                return;
            }
            initialized = true;
            install(image);
            result.complete("Cape applied!");
        }));

        return result;
    }

    private static String describe(Throwable error) {
        Throwable t = error;
        while (t instanceof CompletionException && t.getCause() != null) {
            t = t.getCause();
        }
        LOG.warn("Cape import failed", t);
        if (t instanceof NoSuchFileException) {
            return "File not found.";
        }
        if (t instanceof AccessDeniedException) {
            return "No permission to read that file. Copy it to config/bluecape/photos.";
        }
        if (t instanceof IllegalArgumentException) {
            return String.valueOf(t.getMessage());
        }
        if (t instanceof IOException) {
            return "Can't read that image. Use JPG, PNG, BMP or GIF (not WebP/HEIC).";
        }
        return "Failed: " + t;
    }

    private static NativeImage toImage(int[] pixels) {
        NativeImage image = new NativeImage(CapeComposer.W, CapeComposer.H, true);
        for (int y = 0; y < CapeComposer.H; y++) {
            for (int x = 0; x < CapeComposer.W; x++) {
                image.setColorArgb(x, y, pixels[y * CapeComposer.W + x]);
            }
        }
        return image;
    }

    /** Game thread only. Registers a fresh texture and drops the previous one. */
    private static void install(NativeImage image) {
        TextureManager textures = MinecraftClient.getInstance().getTextureManager();
        Identifier id = Identifier.of("bluecape", "cape_" + (++counter));
        textures.registerTexture(id, new NativeImageBackedTexture(() -> "bluecape " + id, image));
        Identifier old = currentId;
        currentId = id;
        asset = new AssetInfo.TextureAssetInfo(id, id);
        if (old != null) {
            textures.destroyTexture(old);
        }
    }
}
