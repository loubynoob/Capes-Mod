# Blue Cape (Minecraft 1.21.11, Fabric)

A client-side cape mod. By default your player gets a flat blue cape (#1085EE).
You can also make the cape from a color code, from any photo on your phone, or from an
animated GIF, all inside the game.

**Offline friendly:** the mod has no login, no account check and no network code.
It works the same on offline / cracked accounts. Only you see the cape (other players
would need the mod too).

## Opening it

- The **Cape** button in the top-left corner of the title screen or the pause menu, or
- the **Blue Cape** button on Options > Skin Customization (next to Done).

Make sure **Cape** is ticked on the Skin Customization screen.

## The cape screen

It shows your cape and elytra (moving, if you use a GIF) and has three buttons:

- **Photo or GIF** - a list of your newest pictures. Tap one and it becomes your cape.
  GIFs have a `[GIF]` tag. You can also paste a file path and press **Use**.
  - **Whole photo: ON/OFF** - OFF crops the picture to fill the cape, ON fits the whole picture.
  - **Cape file: ON/OFF** - ON if the image already is a cape texture (2:1, like 64x32 or 512x256).
  - **Refresh** looks for new files again.
- **Color** - tap one of the colors, or type a color code like `1085EE` (also `#1085EE` or short `18E`) and press **Apply**.
- **Back to blue** - the plain blue cape again.

The list shows pictures from `DCIM/Camera`, `DCIM`, `Pictures`, `Pictures/Screenshots`,
`Download` on your phone, `.minecraft/screenshots`, and `config/bluecape/photos`.
If your launcher can't read your phone's gallery folders, copy files into
`config/bluecape/photos` and press **Refresh**.

## GIF capes

An animated GIF plays on your cape, and the elytra follows it: the game's own elytra is tinted
to the average color of the current frame. A GIF that does not move is treated like a photo.

- GIFs with more than 100 frames lose frames evenly, the speed stays the same.
- Biggest GIF: 40 MB and 8 megapixels.
- The GIF is copied to `config/bluecape/cape.gif`, so it is still there next launch.

## Elytra

You get the normal elytra from the game (same shape, feathers and shading), tinted to the color
of your cape: blue by default, the color code you apply, or the average color of your picture.
The see-through gaps of the wings are filled in, so the elytra is solid.
With **Cape file: ON** the wings from your cape file are used instead.

Works with JPG, PNG, BMP, GIF, TGA. Not WebP or HEIC (take a screenshot of the picture instead).
Phone photos that are stored rotated come out the right way up.

The cape is remembered in `config/bluecape/cape.png` (or `cape.gif`).

## Building

Needs Java 21. With GitHub Actions: put this zip and `build.yml` (in `.github/workflows/`)
in a repo, run the workflow, and download the jar from the build artifacts.
