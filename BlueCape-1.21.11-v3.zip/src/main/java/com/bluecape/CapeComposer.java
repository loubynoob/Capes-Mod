package com.bluecape;

import java.util.Arrays;

/**
 * Builds the cape texture (512x256 = a 64x32 cape layout scaled up by 8).
 * Pure Java on purpose: it knows nothing about Minecraft, so it can be tested on its own.
 *
 * Cape layout in 64x32 units:
 *   outside of the cape  x=1..11,  y=1..17
 *   inside of the cape   x=12..22, y=1..17
 *   elytra wings         x=24..34 / x=36..46, y=2..22
 */
public final class CapeComposer {
    public static final int SCALE = 8;
    public static final int W = 64 * SCALE;
    public static final int H = 32 * SCALE;
    /** The blue from the screenshot (#1085EE). */
    public static final int BLUE = 0xFF1085EE;

    public enum Fit { FILL, FIT }

    /** Anything that can hand out ARGB pixels. */
    public interface Pixels {
        int width();

        int height();

        int argb(int x, int y);
    }

    private CapeComposer() {
    }

    /** The default cape: flat blue cape, layered blue wings for the elytra. */
    public static int[] defaultCape() {
        return solid(BLUE);
    }

    /**
     * A cape in one colour (0xRRGGBB). The cape itself is flat. The elytra wings get layered
     * feather steps made of shading only: every pixel stays solid (no see-through parts), so the
     * wings look complete from every angle, also when gliding.
     */
    public static int[] solid(int rgb) {
        int[] out = new int[W * H];
        Arrays.fill(out, 0xFF000000 | (rgb & 0xFFFFFF));
        paintWings(out, rgb & 0xFFFFFF);
        return out;
    }

    // Wing design, in cape units (the elytra wing face is 10 wide and 20 tall).
    private static final int[] WING_ROWS = {7, 5, 4, 4};
    /** How much of the outer edge of each row is shaded extra dark (the step). */
    private static final int[] WING_CUTS = {0, 0, 1, 2};
    private static final double WING_BAND = 2.5;
    private static final double WING_BOTTOM = 1.0;

    private static int wingRow(double fy) {
        double top = 0;
        for (int i = 0; i < WING_ROWS.length; i++) {
            top += WING_ROWS[i];
            if (fy < top) {
                return i;
            }
        }
        return WING_ROWS.length - 1;
    }

    /**
     * fx = distance from the outer edge of the wing (0..10), fy = distance from the top (0..20).
     * Returns the (always opaque) pixel for the wing face.
     */
    private static int wingPixel(double fx, double fy, int base, int band, int deep) {
        int row = wingRow(fy);
        if (fx < WING_CUTS[row]) {
            return deep;
        }
        if ((row >= 1 && fx < WING_CUTS[row] + WING_BAND) || fy >= 20 - WING_BOTTOM) {
            return band;
        }
        return base;
    }

    /** Paints both elytra wings (the cape part of the texture is left alone). */
    private static void paintWings(int[] out, int rgb) {
        int base = 0xFF000000 | rgb;
        int band = darken(base, 0.88f);
        int deep = darken(base, 0.76f);
        int edge = darken(base, 0.8f);
        for (int y = 2 * SCALE; y < 22 * SCALE; y++) {
            double fy = (y + 0.5) / SCALE - 2;
            for (int x = 24 * SCALE; x < 34 * SCALE; x++) {         // inside face, outer edge at x=34
                out[y * W + x] = wingPixel(34 - (x + 0.5) / SCALE, fy, base, band, deep);
            }
            for (int x = 36 * SCALE; x < 46 * SCALE; x++) {         // outside face, outer edge at x=36
                out[y * W + x] = wingPixel((x + 0.5) / SCALE - 36, fy, base, band, deep);
            }
            for (int x = 34 * SCALE; x < 36 * SCALE; x++) {         // outer edge of the wing
                out[y * W + x] = edge;
            }
            for (int x = 22 * SCALE; x < 24 * SCALE; x++) {         // inner edge of the wing (by the spine)
                out[y * W + x] = edge;
            }
        }
        for (int y = 0; y < 2 * SCALE; y++) {
            for (int x = 24 * SCALE; x < 34 * SCALE; x++) {         // top of the wing
                out[y * W + x] = base;
            }
            for (int x = 34 * SCALE; x < 44 * SCALE; x++) {         // bottom of the wing
                out[y * W + x] = edge;
            }
        }
    }

    /**
     * Reads a colour code like "#1085EE", "1085ee", "0x1085EE" or the short "18E".
     * Returns 0xRRGGBB, or -1 when the text is not a colour code.
     */
    public static int parseHex(String text) {
        if (text == null) {
            return -1;
        }
        String s = text.trim();
        if (s.startsWith("#")) {
            s = s.substring(1);
        } else if (s.startsWith("0x") || s.startsWith("0X")) {
            s = s.substring(2);
        }
        if (s.length() != 3 && s.length() != 6) {
            return -1;
        }
        int value = 0;
        for (int i = 0; i < s.length(); i++) {
            int digit = Character.digit(s.charAt(i), 16);
            if (digit < 0) {
                return -1;
            }
            value = value * 16 + digit;
        }
        if (s.length() == 3) {
            int r = (value >> 8) & 15;
            int g = (value >> 4) & 15;
            int b = value & 15;
            value = ((r * 17) << 16) | ((g * 17) << 8) | (b * 17);
        }
        return value;
    }

    /** Puts a photo on the outside of the cape (and on the elytra wings). */
    public static int[] fromPhoto(Pixels src, Fit fit) {
        int avg = average(src);
        int[] out = new int[W * H];
        Arrays.fill(out, avg);
        fillRect(out, 12, 1, 10, 16, darken(avg, 0.8f));
        blit(out, src, 1, 1, 10, 16, fit);
        blit(out, src, 24, 2, 10, 20, fit);
        blit(out, src, 36, 2, 10, 20, fit);
        return out;
    }

    /** Uses an image that already is a cape texture (64x32 style, or 46x22 old style). */
    public static int[] fromReadyMade(Pixels src) {
        int sw = src.width();
        int sh = src.height();
        double ratio = (double) sw / sh;
        double fw;
        if (Math.abs(ratio - 2.0) < 0.02) {
            fw = 64;
        } else if (Math.abs(ratio - 46.0 / 22.0) < 0.02) {
            fw = 46;
        } else {
            throw new IllegalArgumentException("A cape file must be 2:1 (like 64x32 or 512x256). This image is " + sw + "x" + sh + ".");
        }
        double k = sw / fw; // source pixels per cape unit
        int[] out = new int[W * H];
        for (int y = 0; y < H; y++) {
            double v0 = y * (32.0 / H) * k;
            double v1 = (y + 1) * (32.0 / H) * k;
            for (int x = 0; x < W; x++) {
                double u0 = x * (64.0 / W) * k;
                double u1 = (x + 1) * (64.0 / W) * k;
                if (u0 >= sw || v0 >= sh) {
                    out[y * W + x] = BLUE;
                } else {
                    out[y * W + x] = sample(src, u0, v0, Math.min(u1, sw), Math.min(v1, sh));
                }
            }
        }
        return out;
    }

    /** Wraps pixels so a phone photo with an EXIF rotation tag comes out the right way up. */
    public static Pixels oriented(Pixels raw, int orientation) {
        if (orientation < 2 || orientation > 8) {
            return raw;
        }
        final int sw = raw.width();
        final int sh = raw.height();
        final boolean swap = orientation >= 5;
        return new Pixels() {
            @Override
            public int width() {
                return swap ? sh : sw;
            }

            @Override
            public int height() {
                return swap ? sw : sh;
            }

            @Override
            public int argb(int x, int y) {
                switch (orientation) {
                    case 2:
                        return raw.argb(sw - 1 - x, y);
                    case 3:
                        return raw.argb(sw - 1 - x, sh - 1 - y);
                    case 4:
                        return raw.argb(x, sh - 1 - y);
                    case 5:
                        return raw.argb(y, x);
                    case 6:
                        return raw.argb(y, sh - 1 - x);
                    case 7:
                        return raw.argb(sw - 1 - y, sh - 1 - x);
                    default: // 8
                        return raw.argb(sw - 1 - y, x);
                }
            }
        };
    }

    /** Reads the EXIF orientation (1..8) from JPEG bytes; 1 when there is none. */
    public static int exifOrientation(byte[] d) {
        if (d.length < 4 || (d[0] & 0xFF) != 0xFF || (d[1] & 0xFF) != 0xD8) {
            return 1;
        }
        int p = 2;
        while (p + 4 <= d.length) {
            if ((d[p] & 0xFF) != 0xFF) {
                return 1;
            }
            int marker = d[p + 1] & 0xFF;
            if (marker == 0xD8 || marker == 0x01 || (marker >= 0xD0 && marker <= 0xD7)) {
                p += 2;
                continue;
            }
            if (marker == 0xDA || marker == 0xD9) {
                return 1;
            }
            int len = ((d[p + 2] & 0xFF) << 8) | (d[p + 3] & 0xFF);
            if (marker == 0xE1 && len >= 8 && p + 10 <= d.length
                    && d[p + 4] == 'E' && d[p + 5] == 'x' && d[p + 6] == 'i' && d[p + 7] == 'f'
                    && d[p + 8] == 0 && d[p + 9] == 0) {
                return tiffOrientation(d, p + 10, Math.min(d.length, p + 2 + len));
            }
            p += 2 + len;
        }
        return 1;
    }

    private static int tiffOrientation(byte[] d, int base, int end) {
        if (base + 8 > end) {
            return 1;
        }
        boolean le;
        if (d[base] == 'I' && d[base + 1] == 'I') {
            le = true;
        } else if (d[base] == 'M' && d[base + 1] == 'M') {
            le = false;
        } else {
            return 1;
        }
        long ifdOffset = u32(d, base + 4, le);
        if (ifdOffset < 8 || base + ifdOffset + 2 > end) {
            return 1;
        }
        int ifd = (int) (base + ifdOffset);
        int count = u16(d, ifd, le);
        for (int i = 0; i < count; i++) {
            int e = ifd + 2 + i * 12;
            if (e + 12 > end) {
                break;
            }
            if (u16(d, e, le) == 0x0112) {
                int v = u16(d, e + 8, le);
                return (v >= 1 && v <= 8) ? v : 1;
            }
        }
        return 1;
    }

    private static int u16(byte[] d, int o, boolean le) {
        int a = d[o] & 0xFF;
        int b = d[o + 1] & 0xFF;
        return le ? (b << 8) | a : (a << 8) | b;
    }

    private static long u32(byte[] d, int o, boolean le) {
        long a = u16(d, o, le);
        long b = u16(d, o + 2, le);
        return le ? (b << 16) | a : (a << 16) | b;
    }

    // ---------------------------------------------------------------- drawing helpers

    private static void blit(int[] out, Pixels src, int ux, int uy, int uw, int uh, Fit fit) {
        int rx = ux * SCALE;
        int ry = uy * SCALE;
        int rw = uw * SCALE;
        int rh = uh * SCALE;
        int sw = src.width();
        int sh = src.height();
        double dstAspect = (double) rw / rh;
        double srcAspect = (double) sw / sh;
        double cx = 0;
        double cy = 0;
        double cw = sw;
        double ch = sh;
        int dx = 0;
        int dy = 0;
        int dw = rw;
        int dh = rh;
        if (fit == Fit.FILL) {
            if (srcAspect > dstAspect) {
                cw = sh * dstAspect;
                cx = (sw - cw) / 2;
            } else {
                ch = sw / dstAspect;
                cy = (sh - ch) / 2;
            }
        } else {
            if (srcAspect > dstAspect) {
                dh = Math.max(1, (int) Math.round(rw / srcAspect));
                dy = (rh - dh) / 2;
            } else {
                dw = Math.max(1, (int) Math.round(rh * srcAspect));
                dx = (rw - dw) / 2;
            }
        }
        for (int y = 0; y < dh; y++) {
            double v0 = cy + y * ch / dh;
            double v1 = cy + (y + 1) * ch / dh;
            for (int x = 0; x < dw; x++) {
                double u0 = cx + x * cw / dw;
                double u1 = cx + (x + 1) * cw / dw;
                out[(ry + dy + y) * W + rx + dx + x] = flatten(sample(src, u0, v0, u1, v1), BLUE);
            }
        }
    }

    private static void fillRect(int[] out, int ux, int uy, int uw, int uh, int color) {
        for (int y = uy * SCALE; y < (uy + uh) * SCALE; y++) {
            for (int x = ux * SCALE; x < (ux + uw) * SCALE; x++) {
                out[y * W + x] = color;
            }
        }
    }

    /** Average colour of a source rectangle (a few samples per output pixel, alpha-aware). */
    static int sample(Pixels src, double u0, double v0, double u1, double v1) {
        int nx = clamp((int) Math.ceil(u1 - u0), 1, 4);
        int ny = clamp((int) Math.ceil(v1 - v0), 1, 4);
        long sa = 0;
        long sr = 0;
        long sg = 0;
        long sb = 0;
        for (int j = 0; j < ny; j++) {
            int py = clamp((int) (v0 + (j + 0.5) * (v1 - v0) / ny), 0, src.height() - 1);
            for (int i = 0; i < nx; i++) {
                int px = clamp((int) (u0 + (i + 0.5) * (u1 - u0) / nx), 0, src.width() - 1);
                int c = src.argb(px, py);
                int a = c >>> 24;
                sa += a;
                sr += (long) ((c >> 16) & 255) * a;
                sg += (long) ((c >> 8) & 255) * a;
                sb += (long) (c & 255) * a;
            }
        }
        if (sa == 0) {
            return 0;
        }
        int n = nx * ny;
        return ((int) (sa / n) << 24) | ((int) (sr / sa) << 16) | ((int) (sg / sa) << 8) | (int) (sb / sa);
    }

    private static int average(Pixels src) {
        long r = 0;
        long g = 0;
        long b = 0;
        int n = 0;
        for (int j = 0; j < 16; j++) {
            for (int i = 0; i < 16; i++) {
                int c = flatten(sample(src,
                        (double) i * src.width() / 16, (double) j * src.height() / 16,
                        (double) (i + 1) * src.width() / 16, (double) (j + 1) * src.height() / 16), BLUE);
                r += (c >> 16) & 255;
                g += (c >> 8) & 255;
                b += c & 255;
                n++;
            }
        }
        return 0xFF000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
    }

    /** Lays a (semi-)transparent colour over a solid background. */
    static int flatten(int c, int bg) {
        int a = c >>> 24;
        if (a == 255) {
            return c;
        }
        int r = (((c >> 16) & 255) * a + ((bg >> 16) & 255) * (255 - a)) / 255;
        int g = (((c >> 8) & 255) * a + ((bg >> 8) & 255) * (255 - a)) / 255;
        int b = ((c & 255) * a + (bg & 255) * (255 - a)) / 255;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int darken(int c, float f) {
        int r = (int) (((c >> 16) & 255) * f);
        int g = (int) (((c >> 8) & 255) * f);
        int b = (int) ((c & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
