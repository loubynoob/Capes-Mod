package com.bluecape;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Pick a photo or a GIF: a list of your newest pictures (gallery folders + config/bluecape/photos),
 * or paste the path of a file. Tapping one makes it your cape and takes you back to the cape screen.
 */
public class PhotoScreen extends Screen {
    private record Photo(Path path, long time) {
    }

    private final CapeScreen parent;
    private final List<Path> photos = new ArrayList<>();
    private ButtonWidget[] rowButtons = new ButtonWidget[0];
    private ButtonWidget prevButton;
    private ButtonWidget nextButton;
    private TextFieldWidget pathField;
    private String pathText = "";
    private int page;
    private int rows = 1;
    private int listTop = 36;
    private int fieldX;
    private int fieldY;
    private int statusY;
    private String status = "";

    public PhotoScreen(CapeScreen parent) {
        super(Text.literal("Photo or GIF"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 110;
        this.rows = Math.max(1, Math.min(8, (this.height - 150) / 22));
        scanPhotos();

        this.rowButtons = new ButtonWidget[rows];
        for (int i = 0; i < rows; i++) {
            final int slot = i;
            rowButtons[i] = this.addDrawableChild(ButtonWidget.builder(Text.empty(), button -> pickRow(slot))
                    .dimensions(left, listTop + i * 22, 220, 20).build());
        }

        int navY = listTop + rows * 22 + 2;
        prevButton = this.addDrawableChild(ButtonWidget.builder(Text.literal("< Prev"), button -> {
            page--;
            refreshRows();
        }).dimensions(left, navY, 68, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Refresh"), button -> {
            scanPhotos();
            page = 0;
            refreshRows();
            status = photos.size() + " files found.";
        }).dimensions(left + 72, navY, 76, 20).build());
        nextButton = this.addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), button -> {
            page++;
            refreshRows();
        }).dimensions(left + 152, navY, 68, 20).build());

        int pathY = navY + 26;
        this.fieldX = left;
        this.fieldY = pathY;
        pathField = new TextFieldWidget(this.textRenderer, left, pathY, 160, 20, Text.literal("File path"));
        pathField.setMaxLength(1024);
        pathField.setText(pathText);
        pathField.setChangedListener(s -> pathText = s);
        this.addDrawableChild(pathField);
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Use"), button -> usePath())
                .dimensions(left + 164, pathY, 56, 20).build());

        int optionsY = pathY + 24;
        this.addDrawableChild(ButtonWidget.builder(fitLabel(), button -> {
            CapeSettings.fit = CapeSettings.fit == CapeComposer.Fit.FILL ? CapeComposer.Fit.FIT : CapeComposer.Fit.FILL;
            CapeSettings.save();
            button.setMessage(fitLabel());
            reapply();
        }).dimensions(left, optionsY, 108, 20).build());
        this.addDrawableChild(ButtonWidget.builder(modeLabel(), button -> {
            CapeSettings.readyMade = !CapeSettings.readyMade;
            CapeSettings.save();
            button.setMessage(modeLabel());
            reapply();
        }).dimensions(left + 112, optionsY, 108, 20).build());

        int backY = optionsY + 24;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Back"), button -> this.close())
                .dimensions(left, backY, 220, 20).build());
        this.statusY = backY + 26;

        refreshRows();
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int cx = this.width / 2;
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, 8, 0xFFFFFFFF);
        if (photos.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("No photos found yet."), cx, listTop + 2, 0xFFFFFFFF);
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Paste a file path below,"), cx, listTop + 16, 0xFFA0A0A0);
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("or put files in config/bluecape/photos"), cx, listTop + 28, 0xFFA0A0A0);
        } else {
            int pages = Math.max(1, (photos.size() + rows - 1) / rows);
            context.drawCenteredTextWithShadow(this.textRenderer,
                    Text.literal("Tap one to use it  (page " + (page + 1) + "/" + pages + ")"), cx, 21, 0xFFA0A0A0);
        }
        if (pathText.isEmpty()) {
            String hint = "Paste a file path here";
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(hint),
                    fieldX + 5 + this.textRenderer.getWidth(hint) / 2, fieldY + 6, 0xFF707070);
        }
        int maxW = this.width - 16;
        int lines = PreviewDraw.lineCount(this.textRenderer, status, maxW);
        PreviewDraw.textBlock(context, this.textRenderer, status, cx, Math.min(statusY, this.height - 2 - lines * 11), maxW, 0xFF7FD7FF);
    }

    // ------------------------------------------------------------------ actions

    private void pickRow(int slot) {
        int index = page * rows + slot;
        if (index < photos.size()) {
            apply(photos.get(index), true);
        }
    }

    private void usePath() {
        String s = pathText.trim();
        if (s.length() >= 2 && ((s.startsWith("\"") && s.endsWith("\"")) || (s.startsWith("'") && s.endsWith("'")))) {
            s = s.substring(1, s.length() - 1).trim();
        }
        if (s.isEmpty()) {
            status = "Paste the path of a photo or GIF first.";
            return;
        }
        try {
            apply(Path.of(s), true);
        } catch (InvalidPathException e) {
            status = "That doesn't look like a file path.";
        }
    }

    /** Changing the photo options redoes the cape that is on right now. */
    private void reapply() {
        if (CapeSettings.lastPath.isEmpty()) {
            return;
        }
        try {
            apply(Path.of(CapeSettings.lastPath), false);
        } catch (InvalidPathException ignored) {
            // nothing to redo
        }
    }

    private void apply(Path file, boolean goBack) {
        status = "Working...";
        CapeSettings.lastPath = file.toString();
        CapeSettings.save();
        CapeManager.importFile(file).thenAccept(message -> {
            boolean ok = message.endsWith("applied!") || message.contains("applied! (");
            if (ok && goBack && this.client != null && this.client.currentScreen == this) {
                parent.setStatus(message);
                this.client.setScreen(parent);
            } else {
                status = message;
            }
        });
    }

    private void refreshRows() {
        int pages = Math.max(1, (photos.size() + rows - 1) / rows);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int i = 0; i < rows; i++) {
            int index = page * rows + i;
            ButtonWidget button = rowButtons[i];
            if (index < photos.size()) {
                button.visible = true;
                button.setMessage(Text.literal(label(photos.get(index))));
            } else {
                button.visible = false;
            }
        }
        prevButton.active = page > 0;
        nextButton.active = page < pages - 1;
    }

    private static Text fitLabel() {
        return Text.literal("Whole photo: " + (CapeSettings.fit == CapeComposer.Fit.FIT ? "ON" : "OFF"));
    }

    private static Text modeLabel() {
        return Text.literal("Cape file: " + (CapeSettings.readyMade ? "ON" : "OFF"));
    }

    private static String label(Path p) {
        String name = p.getFileName().toString();
        boolean gif = name.toLowerCase(Locale.ROOT).endsWith(".gif");
        int max = gif ? 28 : 33;
        String shown = name.length() > max ? name.substring(0, max - 3) + "..." : name;
        return gif ? "[GIF] " + shown : shown;
    }

    // ------------------------------------------------------------------ finding photos

    private static List<Path> photoDirs() {
        List<Path> dirs = new ArrayList<>();
        dirs.add(CapeSettings.dir().resolve("photos"));
        String[] relative = {"DCIM/Camera", "DCIM", "Pictures", "Pictures/Screenshots", "DCIM/Screenshots", "Download"};
        for (String root : new String[]{"/storage/emulated/0", "/sdcard"}) {
            for (String rel : relative) {
                dirs.add(Path.of(root, rel));
            }
        }
        dirs.add(FabricLoader.getInstance().getGameDir().resolve("screenshots"));
        return dirs;
    }

    private static boolean isImage(Path p) {
        String name = p.getFileName().toString().toLowerCase(Locale.ROOT);
        return !name.startsWith(".") && (name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg")
                || name.endsWith(".bmp") || name.endsWith(".gif") || name.endsWith(".tga"));
    }

    private static Path key(Path p) {
        try {
            return p.toRealPath();
        } catch (IOException e) {
            return p.toAbsolutePath().normalize();
        }
    }

    private void scanPhotos() {
        photos.clear();
        Set<Path> seen = new HashSet<>();
        List<Photo> found = new ArrayList<>();
        for (Path dir : photoDirs()) {
            try (Stream<Path> files = Files.list(dir)) {
                for (Path p : (Iterable<Path>) files::iterator) {
                    if (isImage(p) && Files.isRegularFile(p) && seen.add(key(p))) {
                        found.add(new Photo(p, Files.getLastModifiedTime(p).toMillis()));
                    }
                }
            } catch (Exception ignored) {
                // folder missing or not readable: skip it
            }
        }
        found.sort(Comparator.comparingLong(Photo::time).reversed());
        for (int i = 0; i < Math.min(found.size(), 300); i++) {
            photos.add(found.get(i).path());
        }
    }
}
