package com.bluecape;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Client-only. No network, no account checks: works with offline / cracked accounts. */
public class BlueCapeMod implements ClientModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("bluecape");

    @Override
    public void onInitializeClient() {
        CapeSettings.load();
        LOG.info("Blue Cape loaded (offline mode: no network, no account needed)");
    }
}
