package com.bluecape;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/** Pick a flat cape color: tap one of the colors, or type a color code like 1085EE. */
public class ColorScreen extends Screen {
    private static final int[] PRESETS = {
            0x1085EE, 0xE53935, 0xFB8C00, 0xFDD835, 0x43A047, 0x00ACC1,
            0x8E24AA, 0xEC407A, 0xFFFFFF, 0x9E9E9E, 0x424242, 0x6D4C41
    };
    private static final int COLS = 6;

    private final CapeScreen parent;
    private TextFieldWidget colorField;
    private String colorText = CapeSettings.colorHex;
    private int gridX;
    private int gridY;
    private int fieldX;
    private int fieldY;
    private String status = "";

    public ColorScreen(CapeScreen parent) {
        super(Text.literal("Color"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 110;
        this.gridX = left;
        this.gridY = 36;
        for (int i = 0; i < PRESETS.length; i++) {
            final int rgb = PRESETS[i];
            int x = gridX + (i % COLS) * 38;
            int y = gridY + (i / COLS) * 24;
            this.addDrawableChild(ButtonWidget.builder(Text.empty(), button -> applyColor(rgb))
                    .dimensions(x, y, 34, 20).build());
        }

        int rowY = gridY + 2 * 24 + 8;
        this.fieldX = left;
        this.fieldY = rowY;
        colorField = new TextFieldWidget(this.textRenderer, left, rowY, 100, 20, Text.literal("Color code"));
        colorField.setMaxLength(9);
        colorField.setText(colorText);
        colorField.setChangedListener(s -> colorText = s);
        this.addDrawableChild(colorField);
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Apply"), button -> {
            int rgb = CapeComposer.parseHex(colorText);
            if (rgb < 0) {
                status = "Type 6 letters/numbers, like 1085EE.";
                return;
            }
            applyColor(rgb);
        }).dimensions(left + 130, rowY, 90, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Back"), button -> this.close())
                .dimensions(left, rowY + 28, 220, 20).build());
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    private void applyColor(int rgb) {
        String hex = String.format("#%06X", rgb & 0xFFFFFF);
        CapeManager.useColor(rgb);
        CapeSettings.colorHex = hex;
        CapeSettings.save();
        parent.setStatus("Color applied: " + hex);
        this.client.setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int cx = this.width / 2;
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, 8, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Tap a color, or type a color code"), cx, 21, 0xFFA0A0A0);

        // paint the color on top of each color button
        for (int i = 0; i < PRESETS.length; i++) {
            int x = gridX + (i % COLS) * 38;
            int y = gridY + (i / COLS) * 24;
            context.fill(x + 3, y + 3, x + 31, y + 17, 0xFF000000 | PRESETS[i]);
        }

        // the color that is typed in the box
        int typed = CapeComposer.parseHex(colorText);
        if (typed >= 0) {
            PreviewDraw.swatch(context, fieldX + 106, fieldY + 2, 18, 16, typed);
        } else if (!colorText.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("?"), fieldX + 115, fieldY + 6, 0xFFFF7070);
        }
        PreviewDraw.textBlock(context, this.textRenderer, status, cx, fieldY + 56, this.width - 16, 0xFFFF7070);
    }
}
