# Blue Cape (Minecraft 1.21.11, Fabric)

A client-side cape mod. By default your player gets a flat blue cape (#1085EE).
You can also make the cape from any photo on your phone, inside the game.

**Offline friendly:** the mod has no login, no account check and no network code.
It works the same on offline / cracked accounts. Only you see the cape (other players
would need the mod too).

## Using it

1. Open the **Cape** button in the top-left corner of the title screen or the pause menu.
2. Tap a photo from the list (newest first), or paste a file path into the box and press **Use this path**.
3. Look at your player in third person (F5) or in the inventory.

The list shows photos from `DCIM/Camera`, `DCIM`, `Pictures`, `Pictures/Screenshots`,
`Download` on your phone, `.minecraft/screenshots`, and `config/bluecape/photos`.
If your launcher can't read your phone's gallery folders, copy photos into
`config/bluecape/photos` and press **Rescan photos**.

Elytra: you get the normal elytra from the game (same shape, feathers and shading), tinted to the
color of your cape: blue by default, the color code you apply, or the average color of your photo.
If you use **Mode: Cape file**, the wings from that cape file are used instead.
If the elytra still looks old after an update, press **Default blue** once.

Color codes: type a code like `1085EE` (or `#1085EE`, or short like `18E`) in the color box and
press **Apply color** to get a flat cape in that color.

Buttons:
- **Photo: Fill / Fit whole** - crop the photo to fill the cape, or fit the whole photo.
- **Mode: Photo / Cape file** - "Cape file" uses an image that already is a cape texture (64x32 style, 2:1).
- **Default blue** - go back to the plain blue cape.

Works with JPG, PNG, BMP, GIF, TGA. Not WebP or HEIC (take a screenshot of the photo instead).
Phone photos that are stored rotated come out the right way up.

The cape is remembered in `config/bluecape/cape.png`. Make sure **Cape** is ticked under
Options > Skin Customization.

## Building

Needs Java 21. With GitHub Actions: put this zip and `build.yml` (in `.github/workflows/`)
in a repo, run the workflow, and download the jar from the build artifacts.
