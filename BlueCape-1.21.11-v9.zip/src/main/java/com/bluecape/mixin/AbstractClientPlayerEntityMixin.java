package com.bluecape.mixin;

import com.bluecape.CapeManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Swaps the cape texture (and the elytra texture) of YOUR player. For a GIF cape this is a new frame every few ticks. */
@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin {
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void bluecape$useBlueCape(CallbackInfoReturnable<SkinTextures> cir) {
        if ((Object) this != MinecraftClient.getInstance().player) {
            return;
        }
        CapeManager.Look look = CapeManager.look();
        if (look == null || look.cape() == null) {
            return;
        }
        SkinTextures skin = cir.getReturnValue();
        cir.setReturnValue(new SkinTextures(skin.body(), look.cape(),
                look.elytra() == null ? look.cape() : look.elytra(), skin.model(), skin.secure()));
    }
}
