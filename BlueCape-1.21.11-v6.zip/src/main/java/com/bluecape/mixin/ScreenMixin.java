package com.bluecape.mixin;

import com.bluecape.CapeScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Drawable;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds a "Blue Cape" button to Options > Skin Customization.
 * It hooks every screen when it opens, but only acts on the screen whose title is
 * "options.skinCustomisation.title", so no other screen is touched.
 */
@Mixin(Screen.class)
public abstract class ScreenMixin {
    @Shadow
    protected abstract <T extends Element & Drawable & Selectable> T addDrawableChild(T drawableElement);

    // require = 0: if a future game version changes this method, the button is simply missing (no crash)
    @Inject(method = "init(Lnet/minecraft/client/MinecraftClient;II)V", at = @At("TAIL"), require = 0)
    private void bluecape$addSkinScreenButton(MinecraftClient client, int width, int height, CallbackInfo ci) {
        Screen self = (Screen) (Object) this;
        Text title = self.getTitle();
        if (!(title.getContent() instanceof TranslatableTextContent content)
                || !"options.skinCustomisation.title".equals(content.getKey())) {
            return;
        }
        int buttonWidth = 70;
        int x = width / 2 + 104;                 // right of the Done button
        int y = height - 27;
        if (x + buttonWidth > width - 4) {       // no room there (narrow screen): top-left corner instead
            x = 4;
            y = 4;
        }
        this.addDrawableChild(CapeScreen.openButton(self, x, y, buttonWidth, "Blue Cape"));
    }
}
