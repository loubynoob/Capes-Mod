package com.bluecape;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.AssetInfo;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.AccessDeniedException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Owns the cape (and elytra) textures. Everything is local: files in, textures out.
 * There is no login, no session check and no network access anywhere in this mod,
 * so it behaves the same for offline / cracked accounts.
 *
 * A still cape has one frame. A GIF cape has many frames, each one its own texture;
 * the frame that is shown is picked from the clock every time the game asks for the skin.
 */
public final class CapeManager {
    private static final Logger LOG = LoggerFactory.getLogger("bluecape");
    private static final Executor WORKER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "bluecape-worker");
        t.setDaemon(true);
        return t;
    });

    /** A GIF with more frames than this loses frames evenly (the timing stays right). */
    static final int MAX_FRAMES = 100;
    /** Pixels per cape unit for GIF frames: 4 means 256x128 per frame (a still cape uses 8 = 512x256). */
    static final int GIF_SCALE = 4;
    private static final long MAX_FILE_BYTES = 40L * 1024 * 1024;
    private static final String DEFAULT_ELYTRA = "#1085EE";

    /** What the renderer gets for this moment: the cape texture and the elytra texture. */
    public record Look(AssetInfo.TextureAsset cape, AssetInfo.TextureAsset elytra) {
    }

    /** The cape that is installed right now. */
    private static final class Installed {
        List<Identifier> ids = new ArrayList<>();
        Look[] looks;
        long[] ends;                 // end time of each frame, in ms since the start of the loop
        int[][] capePreview;
        int[][] wingPreview;
        long startMs;
        String label;

        int frameAt(long nowMs) {
            if (looks.length == 1) {
                return 0;
            }
            long total = ends[ends.length - 1];
            long t = (nowMs - startMs) % total;
            if (t < 0) {
                t += total;
            }
            for (int i = 0; i < ends.length; i++) {
                if (t < ends[i]) {
                    return i;
                }
            }
            return ends.length - 1;
        }
    }

    /** A cape that was made on the worker thread and waits to be turned into textures. */
    private record Built(NativeImage[] capes, int[] delays, int[] elytraRgb, int[][] capePreview,
                         int[][] wingFromCape, boolean animated, String elytraSpec, String label) {
    }

    private static boolean initialized;
    private static int counter;
    private static int generation;
    private static Installed current;

    private CapeManager() {
    }

    // ------------------------------------------------------------------ what the screens and the mixin ask

    /** The textures to use right now (null only if something went badly wrong). */
    public static Look look() {
        ensureInit();
        Installed c = current;
        return c == null ? null : c.looks[c.frameAt(nowMs())];
    }

    /** The outside of the cape as CapeComposer.PREVIEW_W x PREVIEW_H colours, for the frame shown now. */
    public static int[] capePreview() {
        ensureInit();
        Installed c = current;
        return c == null ? null : c.capePreview[c.frameAt(nowMs())];
    }

    /** One wing as CapeComposer.WING_W x WING_H colours, for the frame shown now. */
    public static int[] wingPreview() {
        ensureInit();
        Installed c = current;
        return c == null ? null : c.wingPreview[c.frameAt(nowMs())];
    }

    /** Short description of what is installed, like "Default blue" or "GIF: cat.gif (24 frames)". */
    public static String label() {
        ensureInit();
        Installed c = current;
        return c == null ? "" : c.label;
    }

    private static void ensureInit() {
        if (!initialized) {
            initialized = true;
            loadSavedOrDefault();
        }
    }

    private static long nowMs() {
        return System.nanoTime() / 1_000_000L;
    }

    // ------------------------------------------------------------------ loading and the simple capes

    private static void loadSavedOrDefault() {
        Path gif = CapeSettings.dir().resolve("cape.gif");
        Path saved = CapeSettings.dir().resolve("cape.png");
        if (Files.isRegularFile(gif)) {
            // the blue cape shows right away, the GIF replaces it as soon as it is read
            installStill(toImage(CapeComposer.defaultCape(), CapeComposer.SCALE), CapeComposer.defaultCape(),
                    DEFAULT_ELYTRA, "Loading your GIF...");
            final int gen = generation;
            final CapeComposer.Fit fit = CapeSettings.fit;
            final boolean readyMade = CapeSettings.readyMade;
            CompletableFuture.supplyAsync(() -> {
                try {
                    return build(Files.readAllBytes(gif), "cape.gif", fit, readyMade);
                } catch (IOException e) {
                    throw new CompletionException(e);
                }
            }, WORKER).whenComplete((built, error) -> MinecraftClient.getInstance().execute(() -> {
                if (error != null) {
                    LOG.warn("Could not load the saved GIF cape, keeping the default blue one", error);
                    return;
                }
                if (gen != generation) {                  // the player picked something else meanwhile
                    closeAll(built.capes());
                    return;
                }
                String savedLabel = CapeSettings.label.isEmpty() ? built.label() : CapeSettings.label;
                install(built.capes(), built.delays(), built.elytraRgb(), built.capePreview(), built.wingFromCape(), savedLabel);
            }));
            return;
        }
        if (Files.isRegularFile(saved)) {
            try {
                NativeImage image = NativeImage.read(Files.readAllBytes(saved));
                String elytra = CapeSettings.elytra;
                int[] pixels = pixelsOf(image);
                if (elytra.isEmpty()) {
                    // older save without an elytra colour: use the average colour of the saved cape
                    elytra = String.format("#%06X", CapeComposer.averageColor(pixels, image.getWidth() / 64));
                }
                installStill(image, pixels, elytra, CapeSettings.label.isEmpty() ? "Photo" : CapeSettings.label);
                return;
            } catch (Exception e) {
                LOG.warn("Could not load saved cape, using the default blue one", e);
            }
        }
        installStill(toImage(CapeComposer.defaultCape(), CapeComposer.SCALE), CapeComposer.defaultCape(),
                DEFAULT_ELYTRA, "Default blue");
    }

    /** Back to the plain blue cape. */
    public static void useDefault() {
        initialized = true;
        generation++;
        installStill(toImage(CapeComposer.defaultCape(), CapeComposer.SCALE), CapeComposer.defaultCape(),
                DEFAULT_ELYTRA, "Default blue");
        deleteSaved();
        CapeSettings.lastPath = "";
        CapeSettings.elytra = DEFAULT_ELYTRA;
        CapeSettings.label = "Default blue";
        CapeSettings.save();
    }

    /** A flat cape in one colour (0xRRGGBB), saved so it is still there next launch. */
    public static void useColor(int rgb) {
        initialized = true;
        generation++;
        int[] pixels = CapeComposer.solid(rgb);
        NativeImage image = toImage(pixels, CapeComposer.SCALE);
        try {
            Files.createDirectories(CapeSettings.dir());
            image.writeTo(CapeSettings.dir().resolve("cape.png"));
            Files.deleteIfExists(CapeSettings.dir().resolve("cape.gif"));
        } catch (IOException e) {
            LOG.warn("Could not save cape.png (the cape still works this session)", e);
        }
        String hex = String.format("#%06X", rgb & 0xFFFFFF);
        installStill(image, pixels, hex, "Color " + hex);
        CapeSettings.lastPath = "";
        CapeSettings.elytra = hex;
        CapeSettings.label = "Color " + hex;
        CapeSettings.save();
    }

    private static void deleteSaved() {
        try {
            Files.deleteIfExists(CapeSettings.dir().resolve("cape.png"));
            Files.deleteIfExists(CapeSettings.dir().resolve("cape.gif"));
        } catch (IOException ignored) {
            // not fatal
        }
    }

    // ------------------------------------------------------------------ photos and GIFs

    /**
     * Turns an image file (photo or GIF) into the cape. Reading and scaling happen on a worker thread,
     * the texture upload happens on the game thread. The future completes with a short
     * message for the screen, on the game thread.
     */
    public static CompletableFuture<String> importFile(Path file) {
        final CapeComposer.Fit fit = CapeSettings.fit;
        final boolean readyMade = CapeSettings.readyMade;
        final CompletableFuture<String> result = new CompletableFuture<>();
        generation++;                                      // cancels a saved GIF that is still loading

        CompletableFuture.supplyAsync(() -> {
            try {
                if (Files.size(file) > MAX_FILE_BYTES) {
                    throw new IllegalArgumentException("That file is too big (the limit is 40 MB).");
                }
                byte[] data = Files.readAllBytes(file);
                Built built = build(data, file.getFileName().toString(), fit, readyMade);
                persist(built, data);
                return built;
            } catch (IOException e) {
                throw new CompletionException(e);
            }
        }, WORKER).whenComplete((built, error) -> MinecraftClient.getInstance().execute(() -> {
            if (error != null) {
                result.complete(describe(error));
                return;
            }
            initialized = true;
            installBuilt(built);
            CapeSettings.elytra = built.animated() ? "" : built.elytraSpec();
            CapeSettings.label = built.label();
            CapeSettings.save();
            result.complete(built.animated()
                    ? "GIF cape applied! (" + built.capes().length + " frames)"
                    : "Cape applied!");
        }));

        return result;
    }

    /** Worker thread: file bytes in, textures-to-be out. */
    private static Built build(byte[] data, String name, CapeComposer.Fit fit, boolean readyMade) throws IOException {
        if (GifDecoder.isGif(data)) {
            return buildGif(data, name, fit, readyMade);
        }
        int orientation = CapeComposer.exifOrientation(data);
        try (NativeImage src = NativeImage.read(data)) {
            CapeComposer.Pixels raw = pixelsOfImage(src);
            int[] pixels = readyMade
                    ? CapeComposer.fromReadyMade(raw)
                    : CapeComposer.fromPhoto(CapeComposer.oriented(raw, orientation), fit);
            return still(pixels, CapeComposer.SCALE, readyMade, (readyMade ? "Cape file: " : "Photo: ") + shorten(name));
        }
    }

    private static Built buildGif(byte[] data, String name, CapeComposer.Fit fit, boolean readyMade) throws IOException {
        final int count = GifDecoder.countFrames(data);
        if (count == 1) {                                   // a GIF that does not move is just a photo
            final int[][] only = new int[1][];
            final int[] size = new int[2];
            GifDecoder.decode(data, (index, canvas, w, h, ms) -> {
                only[0] = canvas.clone();
                size[0] = w;
                size[1] = h;
            });
            CapeComposer.Pixels raw = pixelsOfArray(only[0], size[0], size[1]);
            int[] pixels = readyMade ? CapeComposer.fromReadyMade(raw) : CapeComposer.fromPhoto(raw, fit);
            return still(pixels, CapeComposer.SCALE, readyMade, (readyMade ? "Cape file: " : "Photo: ") + shorten(name));
        }

        final int step = Math.max(1, (count + MAX_FRAMES - 1) / MAX_FRAMES);
        final List<NativeImage> capes = new ArrayList<>();
        final List<Integer> delays = new ArrayList<>();
        final List<Integer> colors = new ArrayList<>();
        final List<int[]> capePreviews = new ArrayList<>();
        final List<int[]> wingPreviews = new ArrayList<>();
        try {
            GifDecoder.decode(data, (index, canvas, w, h, ms) -> {
                if (index % step != 0) {                    // a frame we skip: its time goes to the one before
                    int last = delays.size() - 1;
                    delays.set(last, delays.get(last) + ms);
                    return;
                }
                CapeComposer.Pixels raw = pixelsOfArray(canvas, w, h);
                int[] cape = readyMade
                        ? CapeComposer.fromReadyMade(raw, GIF_SCALE)
                        : CapeComposer.fromPhoto(raw, fit, GIF_SCALE);
                int cw = 64 * GIF_SCALE;
                int ch = 32 * GIF_SCALE;
                capes.add(toImage(cape, GIF_SCALE));
                delays.add(ms);
                colors.add(readyMade ? 0 : CapeComposer.averageColor(cape, GIF_SCALE));
                capePreviews.add(CapeComposer.capePreview(cape, cw, ch));
                wingPreviews.add(CapeComposer.wingPreview(cape, cw, ch));
            });
        } catch (IOException | RuntimeException e) {
            closeAll(capes.toArray(new NativeImage[0]));
            throw e;
        }
        int n = capes.size();
        int[] delayArray = new int[n];
        int[] colorArray = readyMade ? null : new int[n];
        for (int i = 0; i < n; i++) {
            delayArray[i] = delays.get(i);
            if (colorArray != null) {
                colorArray[i] = colors.get(i);
            }
        }
        return new Built(capes.toArray(new NativeImage[0]), delayArray, colorArray,
                capePreviews.toArray(new int[0][]), wingPreviews.toArray(new int[0][]),
                true, "", "GIF: " + shorten(name) + " (" + n + " frames)");
    }

    private static Built still(int[] pixels, int scale, boolean readyMade, String label) {
        int w = 64 * scale;
        int h = 32 * scale;
        String spec = readyMade ? "file" : String.format("#%06X", CapeComposer.averageColor(pixels, scale));
        int[] rgb = readyMade ? null : new int[]{CapeComposer.averageColor(pixels, scale)};
        return new Built(new NativeImage[]{toImage(pixels, scale)}, new int[]{1000}, rgb,
                new int[][]{CapeComposer.capePreview(pixels, w, h)}, new int[][]{CapeComposer.wingPreview(pixels, w, h)},
                false, spec, label);
    }

    /** Worker thread: remember the cape for the next launch. */
    private static void persist(Built built, byte[] gifBytes) {
        try {
            Files.createDirectories(CapeSettings.dir());
            if (built.animated()) {
                Files.write(CapeSettings.dir().resolve("cape.gif"), gifBytes);
                Files.deleteIfExists(CapeSettings.dir().resolve("cape.png"));
            } else {
                built.capes()[0].writeTo(CapeSettings.dir().resolve("cape.png"));
                Files.deleteIfExists(CapeSettings.dir().resolve("cape.gif"));
            }
        } catch (IOException e) {
            LOG.warn("Could not save the cape (it still works this session)", e);
        }
    }

    private static String shorten(String name) {
        return name.length() > 24 ? name.substring(0, 21) + "..." : name;
    }

    private static void closeAll(NativeImage[] images) {
        for (NativeImage image : images) {
            try {
                image.close();
            } catch (RuntimeException ignored) {
                // nothing more to do
            }
        }
    }

    private static String describe(Throwable error) {
        Throwable t = error;
        while (t instanceof CompletionException && t.getCause() != null) {
            t = t.getCause();
        }
        LOG.warn("Cape import failed", t);
        if (t instanceof NoSuchFileException) {
            return "File not found.";
        }
        if (t instanceof AccessDeniedException) {
            return "No permission to read that file. Copy it to config/bluecape/photos.";
        }
        if (t instanceof IllegalArgumentException) {
            return String.valueOf(t.getMessage());
        }
        if (t instanceof OutOfMemoryError) {
            return "That file is too big for the game's memory.";
        }
        if (t instanceof IOException) {
            return "Can't read that image. Use JPG, PNG, BMP or GIF (not WebP/HEIC).";
        }
        return "Failed: " + t;
    }

    // ------------------------------------------------------------------ pixels <-> images

    private static NativeImage toImage(int[] pixels, int scale) {
        int w = 64 * scale;
        int h = 32 * scale;
        NativeImage image = new NativeImage(w, h, true);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                image.setColorArgb(x, y, pixels[y * w + x]);
            }
        }
        return image;
    }

    private static int[] pixelsOf(NativeImage image) {
        int[] out = new int[image.getWidth() * image.getHeight()];
        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                out[y * image.getWidth() + x] = image.getColorArgb(x, y);
            }
        }
        return out;
    }

    private static CapeComposer.Pixels pixelsOfImage(NativeImage src) {
        return new CapeComposer.Pixels() {
            @Override
            public int width() {
                return src.getWidth();
            }

            @Override
            public int height() {
                return src.getHeight();
            }

            @Override
            public int argb(int x, int y) {
                return src.getColorArgb(x, y);
            }
        };
    }

    private static CapeComposer.Pixels pixelsOfArray(int[] px, int w, int h) {
        return new CapeComposer.Pixels() {
            @Override
            public int width() {
                return w;
            }

            @Override
            public int height() {
                return h;
            }

            @Override
            public int argb(int x, int y) {
                return px[y * w + x];
            }
        };
    }

    // ------------------------------------------------------------------ the game's elytra

    /** The game's own elytra picture, as plain pixels. */
    private record ElytraBase(int[] pixels, int width, int height) {
    }

    /**
     * The game's own elytra texture (whatever the active resource packs say).
     * Returns null when it can't be found, then the cape texture is used for the elytra.
     */
    private static ElytraBase loadVanillaElytra() {
        try {
            ResourceManager resources = MinecraftClient.getInstance().getResourceManager();
            Identifier canonical = Identifier.ofVanilla("textures/entity/equipment/wings/elytra.png");
            Identifier found = null;
            for (Identifier id : resources.findResources("textures/entity", p -> p.getPath().endsWith("elytra.png")).keySet()) {
                if (id.equals(canonical)) {
                    found = id;                      // the one the game really uses
                    break;
                }
                if ("minecraft".equals(id.getNamespace()) && id.getPath().endsWith("/elytra.png")
                        && (found == null || id.getPath().length() < found.getPath().length())) {
                    found = id;
                }
            }
            if (found == null) {
                LOG.warn("Could not find the game's elytra texture, using the cape texture for the elytra");
                return null;
            }
            try (InputStream in = resources.open(found); NativeImage src = NativeImage.read(in)) {
                return new ElytraBase(pixelsOf(src), src.getWidth(), src.getHeight());
            }
        } catch (Exception e) {
            LOG.warn("Could not read the elytra, using the cape texture for the elytra", e);
            return null;
        }
    }

    // ------------------------------------------------------------------ making textures (game thread)

    private static void installBuilt(Built b) {
        install(b.capes(), b.delays(), b.elytraRgb(), b.capePreview(), b.wingFromCape(), b.label());
    }

    private static void installStill(NativeImage image, int[] pixels, String elytraSpec, String label) {
        int w = image.getWidth();
        int h = image.getHeight();
        int[] rgb = null;
        if (!"file".equals(elytraSpec)) {
            int parsed = CapeComposer.parseHex(elytraSpec);
            rgb = new int[]{parsed < 0 ? (CapeComposer.BLUE & 0xFFFFFF) : parsed};
        }
        install(new NativeImage[]{image}, new int[]{1000}, rgb,
                new int[][]{CapeComposer.capePreview(pixels, w, h)}, new int[][]{CapeComposer.wingPreview(pixels, w, h)}, label);
    }

    /**
     * Game thread only. Registers fresh textures (one per frame) and drops the previous ones.
     * elytraRgb has one colour per frame (the game's elytra is tinted to it), or is null to use
     * the cape textures for the elytra too (a ready-made cape file brings its own wings).
     */
    private static void install(NativeImage[] capes, int[] delays, int[] elytraRgb,
                                int[][] capePreview, int[][] wingFromCape, String label) {
        TextureManager textures = MinecraftClient.getInstance().getTextureManager();
        int n = ++counter;
        int frames = capes.length;
        Installed next = new Installed();

        AssetInfo.TextureAsset[] capeAssets = new AssetInfo.TextureAsset[frames];
        for (int i = 0; i < frames; i++) {
            final Identifier id = Identifier.of("bluecape", "cape_" + n + "_" + i);
            final NativeImage image = capes[i];
            textures.registerTexture(id, new NativeImageBackedTexture(() -> "bluecape " + id, image));
            capeAssets[i] = new AssetInfo.TextureAssetInfo(id, id);
            next.ids.add(id);
        }

        AssetInfo.TextureAsset[] elytraAssets = capeAssets;
        int[][] wings = wingFromCape;
        ElytraBase base = elytraRgb == null ? null : loadVanillaElytra();
        if (base != null) {
            elytraAssets = new AssetInfo.TextureAsset[frames];
            wings = new int[frames][];
            Map<Integer, Integer> sameColor = new HashMap<>();      // frames with the same colour share one texture
            for (int i = 0; i < frames; i++) {
                int rgb = elytraRgb[i] & 0xFFFFFF;
                Integer twin = sameColor.get(rgb);
                if (twin != null) {
                    elytraAssets[i] = elytraAssets[twin];
                    wings[i] = wings[twin];
                    continue;
                }
                final int[] tinted = CapeComposer.recolorElytra(pixelsOfArray(base.pixels(), base.width(), base.height()), rgb);
                CapeComposer.fillElytraGaps(tinted, base.width(), base.height());
                final NativeImage image = new NativeImage(base.width(), base.height(), true);
                for (int y = 0; y < base.height(); y++) {
                    for (int x = 0; x < base.width(); x++) {
                        image.setColorArgb(x, y, tinted[y * base.width() + x]);
                    }
                }
                final Identifier id = Identifier.of("bluecape", "elytra_" + n + "_" + i);
                textures.registerTexture(id, new NativeImageBackedTexture(() -> "bluecape " + id, image));
                elytraAssets[i] = new AssetInfo.TextureAssetInfo(id, id);
                wings[i] = CapeComposer.wingPreview(tinted, base.width(), base.height());
                next.ids.add(id);
                sameColor.put(rgb, i);
            }
        }

        next.looks = new Look[frames];
        next.ends = new long[frames];
        long t = 0;
        for (int i = 0; i < frames; i++) {
            next.looks[i] = new Look(capeAssets[i], elytraAssets[i]);
            t += Math.max(20, delays[i]);
            next.ends[i] = t;
        }
        next.capePreview = capePreview;
        next.wingPreview = wings;
        next.startMs = nowMs();
        next.label = label;

        Installed old = current;
        current = next;
        if (old != null) {
            for (Identifier id : old.ids) {
                textures.destroyTexture(id);
            }
        }
    }
}
