package com.bluecape.mixin;

import com.bluecape.CapeManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.AssetInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Swaps the cape (and elytra) texture of YOUR player for the Blue Cape texture. */
@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin {
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void bluecape$useBlueCape(CallbackInfoReturnable<SkinTextures> cir) {
        if ((Object) this != MinecraftClient.getInstance().player) {
            return;
        }
        AssetInfo.TextureAsset cape = CapeManager.get();
        if (cape == null) {
            return;
        }
        SkinTextures skin = cir.getReturnValue();
        cir.setReturnValue(new SkinTextures(skin.body(), cape, cape, skin.model(), skin.secure()));
    }
}
