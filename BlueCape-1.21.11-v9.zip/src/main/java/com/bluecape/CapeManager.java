package com.bluecape;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.AssetInfo;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.nio.file.AccessDeniedException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.Locale;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Owns the cape (and elytra) textures. Everything is local: files in, textures out.
 * There is no login and no session check anywhere in this mod, so it behaves the same for
 * offline / cracked accounts. The only time it uses the internet is when you paste a link to a
 * picture (importLink): it downloads that one file and sends nothing about you.
 *
 * A still cape has one frame. A GIF cape has many frames, each one its own texture;
 * the frame that is shown is picked from the clock every time the game asks for the skin.
 */
public final class CapeManager {
    private static final Logger LOG = LoggerFactory.getLogger("bluecape");
    private static final Executor WORKER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "bluecape-worker");
        t.setDaemon(true);
        return t;
    });

    /** A GIF with more frames than this loses frames evenly (the timing stays right). */
    static final int MAX_FRAMES = 100;
    /** Pixels per cape unit for GIF frames at Normal quality: 4 means 256x128 per frame (a still cape uses 8 = 512x256). */
    static final int GIF_SCALE = 4;
    /** Pixels per cape unit at Normal / High / 4K for still capes (64 = 4096x2048). */
    private static final int[] STILL_SCALE = {8, 16, 64};
    /** Biggest pixels per cape unit a GIF frame may have at Normal / High / 4K. */
    private static final int[] GIF_MAX_SCALE = {4, 16, 64};
    private static final long MAX_FILE_BYTES = 40L * 1024 * 1024;
    private static final String DEFAULT_ELYTRA = "#1085EE";

    /** What the renderer gets for this moment: the cape texture and the elytra texture. */
    public record Look(AssetInfo.TextureAsset cape, AssetInfo.TextureAsset elytra) {
    }

    /** The cape that is installed right now. */
    private static final class Installed {
        List<Identifier> ids = new ArrayList<>();
        Look[] looks;                // cape + the game's feathers tinted to the cape color
        Look[] picLooks;             // cape + the cape picture on the wings (same as looks for a flat color)
        boolean hasPicture;          // false for a flat color: there is no picture to put on the wings
        long[] ends;                 // end time of each frame, in ms since the start of the loop
        int[][] capePreview;
        int[][] wingPreview;
        int[][] picWingPreview;
        long startMs;
        String label;

        int frameAt(long nowMs) {
            if (looks.length == 1) {
                return 0;
            }
            long total = ends[ends.length - 1];
            long t = (nowMs - startMs) % total;
            if (t < 0) {
                t += total;
            }
            for (int i = 0; i < ends.length; i++) {
                if (t < ends[i]) {
                    return i;
                }
            }
            return ends.length - 1;
        }
    }

    /** A cape that was made on the worker thread and waits to be turned into textures. */
    private record Built(NativeImage[] capes, int[] delays, int[] elytraRgb, int[][] capePreview,
                         int[][] wingFromCape, boolean animated, String elytraSpec, String label) {
    }

    private static boolean initialized;
    private static int counter;
    private static int generation;
    private static Installed current;

    private CapeManager() {
    }

    // ------------------------------------------------------------------ picture size (quality)

    /** Bytes of picture memory the game may spend on one cape: about an eighth of its memory, 96..384 MB. */
    private static long pictureBudget() {
        long eighth = Runtime.getRuntime().maxMemory() / 8;
        return Math.max(96L << 20, Math.min(384L << 20, eighth));
    }

    /** Memory of one cape texture: 64s x 32s pixels, 4 bytes each. */
    private static long textureBytes(int scale) {
        return 8192L * scale * scale;
    }

    /** Pixels per cape unit for a still cape at the chosen quality (64 = 4096x2048). */
    static int stillScale() {
        int scale = STILL_SCALE[CapeSettings.quality];
        while (scale > 8 && textureBytes(scale) * 2 > pictureBudget()) {
            scale /= 2;
        }
        return scale;
    }

    /** Pixels per cape unit for each frame of a GIF with this many frames: the biggest that fits in memory. */
    static int gifScale(int frames) {
        int cap = GIF_MAX_SCALE[CapeSettings.quality];
        for (int scale = 64; scale > GIF_SCALE; scale /= 2) {
            if (scale <= cap && frames * textureBytes(scale) <= pictureBudget()) {
                return scale;
            }
        }
        return GIF_SCALE;
    }

    /** "4096x2048" for a cape texture. */
    private static String sizeText(NativeImage image) {
        return image.getWidth() + "x" + image.getHeight();
    }

    // ------------------------------------------------------------------ what the screens and the mixin ask

    /** The textures to use right now (null only if something went badly wrong). */
    public static Look look() {
        ensureInit();
        Installed c = current;
        if (c == null) {
            return null;
        }
        int i = c.frameAt(nowMs());
        return CapeSettings.elytraPicture ? c.picLooks[i] : c.looks[i];
    }

    /** true when the current cape has a picture the elytra can show (false for a flat color). */
    public static boolean hasElytraPicture() {
        ensureInit();
        Installed c = current;
        return c != null && c.hasPicture;
    }

    /** The outside of the cape as CapeComposer.PREVIEW_W x PREVIEW_H colours, for the frame shown now. */
    public static int[] capePreview() {
        ensureInit();
        Installed c = current;
        return c == null ? null : c.capePreview[c.frameAt(nowMs())];
    }

    /** One wing as CapeComposer.WING_W x WING_H colours, for the frame shown now. */
    public static int[] wingPreview() {
        ensureInit();
        Installed c = current;
        if (c == null) {
            return null;
        }
        int i = c.frameAt(nowMs());
        return CapeSettings.elytraPicture ? c.picWingPreview[i] : c.wingPreview[i];
    }

    /** Short description of what is installed, like "Default blue" or "GIF: cat.gif (24 frames)". */
    public static String label() {
        ensureInit();
        Installed c = current;
        return c == null ? "" : c.label;
    }

    private static void ensureInit() {
        if (!initialized) {
            initialized = true;
            loadSavedOrDefault();
        }
    }

    private static long nowMs() {
        return System.nanoTime() / 1_000_000L;
    }

    // ------------------------------------------------------------------ loading and the simple capes

    private static void loadSavedOrDefault() {
        Path gif = CapeSettings.dir().resolve("cape.gif");
        Path saved = CapeSettings.dir().resolve("cape.png");
        if (Files.isRegularFile(gif)) {
            // the blue cape shows right away, the GIF replaces it as soon as it is read
            installStill(toImage(CapeComposer.defaultCape(), CapeComposer.SCALE), CapeComposer.defaultCape(),
                    DEFAULT_ELYTRA, "Loading your GIF...");
            final int gen = generation;
            final CapeComposer.Fit fit = CapeSettings.fit;
            final boolean readyMade = CapeSettings.readyMade;
            CompletableFuture.supplyAsync(() -> {
                try {
                    return build(Files.readAllBytes(gif), "cape.gif", fit, readyMade);
                } catch (IOException e) {
                    throw new CompletionException(e);
                }
            }, WORKER).whenComplete((built, error) -> MinecraftClient.getInstance().execute(() -> {
                if (error != null) {
                    LOG.warn("Could not load the saved GIF cape, keeping the default blue one", error);
                    return;
                }
                if (gen != generation) {                  // the player picked something else meanwhile
                    closeAll(built.capes());
                    return;
                }
                String savedLabel = CapeSettings.label.isEmpty() ? built.label() : CapeSettings.label;
                install(built.capes(), built.delays(), built.elytraRgb(), built.capePreview(), built.wingFromCape(), savedLabel);
            }));
            return;
        }
        if (Files.isRegularFile(saved)) {
            try {
                NativeImage image = NativeImage.read(Files.readAllBytes(saved));
                String elytra = CapeSettings.elytra;
                int[] pixels = pixelsOf(image);
                if (elytra.isEmpty()) {
                    // older save without an elytra colour: use the average colour of the saved cape
                    elytra = String.format("#%06X", CapeComposer.averageColor(pixels, image.getWidth() / 64));
                }
                installStill(image, pixels, elytra, CapeSettings.label.isEmpty() ? "Photo" : CapeSettings.label);
                return;
            } catch (Exception e) {
                LOG.warn("Could not load saved cape, using the default blue one", e);
            }
        }
        installStill(toImage(CapeComposer.defaultCape(), CapeComposer.SCALE), CapeComposer.defaultCape(),
                DEFAULT_ELYTRA, "Default blue");
    }

    /** Back to the plain blue cape. */
    public static void useDefault() {
        initialized = true;
        generation++;
        installStill(toImage(CapeComposer.defaultCape(), CapeComposer.SCALE), CapeComposer.defaultCape(),
                DEFAULT_ELYTRA, "Default blue");
        deleteSaved();
        CapeSettings.lastPath = "";
        CapeSettings.elytra = DEFAULT_ELYTRA;
        CapeSettings.label = "Default blue";
        CapeSettings.save();
    }

    /** A flat cape in one colour (0xRRGGBB), saved so it is still there next launch. */
    public static void useColor(int rgb) {
        initialized = true;
        generation++;
        int[] pixels = CapeComposer.solid(rgb);
        NativeImage image = toImage(pixels, CapeComposer.SCALE);
        try {
            Files.createDirectories(CapeSettings.dir());
            image.writeTo(CapeSettings.dir().resolve("cape.png"));
            Files.deleteIfExists(CapeSettings.dir().resolve("cape.gif"));
        } catch (IOException e) {
            LOG.warn("Could not save cape.png (the cape still works this session)", e);
        }
        String hex = String.format("#%06X", rgb & 0xFFFFFF);
        installStill(image, pixels, hex, "Color " + hex);
        CapeSettings.lastPath = "";
        CapeSettings.elytra = hex;
        CapeSettings.label = "Color " + hex;
        CapeSettings.save();
    }

    /** A cape of one or two colours (0xRRGGBB) in a pattern, saved so it is still there next launch. */
    public static void usePattern(CapeComposer.Pattern pattern, int rgb1, int rgb2) {
        initialized = true;
        generation++;
        int[] pixels = CapeComposer.pattern(pattern, rgb1, rgb2, CapeComposer.SCALE);
        NativeImage image = toImage(pixels, CapeComposer.SCALE);
        try {
            Files.createDirectories(CapeSettings.dir());
            image.writeTo(CapeSettings.dir().resolve("cape.png"));
            Files.deleteIfExists(CapeSettings.dir().resolve("cape.gif"));
        } catch (IOException e) {
            LOG.warn("Could not save cape.png (the cape still works this session)", e);
        }
        // the elytra gets the average color of the outside of the cape
        String hex = String.format("#%06X", CapeComposer.averageColor(pixels, CapeComposer.SCALE));
        String label = pattern == CapeComposer.Pattern.SOLID
                ? "Color " + String.format("#%06X", rgb1 & 0xFFFFFF)
                : "Palette: " + pattern.label;
        installStill(image, pixels, hex, label);
        CapeSettings.lastPath = "";
        CapeSettings.elytra = hex;
        CapeSettings.label = label;
        CapeSettings.save();
    }

    private static void deleteSaved() {
        try {
            Files.deleteIfExists(CapeSettings.dir().resolve("cape.png"));
            Files.deleteIfExists(CapeSettings.dir().resolve("cape.gif"));
        } catch (IOException ignored) {
            // not fatal
        }
    }

    // ------------------------------------------------------------------ photos and GIFs

    /**
     * Turns an image file (photo or GIF) into the cape. Reading and scaling happen on a worker thread,
     * the texture upload happens on the game thread. The future completes with a short
     * message for the screen, on the game thread.
     */
    public static CompletableFuture<String> importFile(Path file) {
        final CapeComposer.Fit fit = CapeSettings.fit;
        final boolean readyMade = CapeSettings.readyMade;
        final CompletableFuture<String> result = new CompletableFuture<>();
        generation++;                                      // cancels a saved GIF that is still loading

        CompletableFuture.supplyAsync(() -> {
            try {
                if (Files.size(file) > MAX_FILE_BYTES) {
                    throw new IllegalArgumentException("That file is too big (the limit is 40 MB).");
                }
                byte[] data = Files.readAllBytes(file);
                Built built = build(data, file.getFileName().toString(), fit, readyMade);
                persist(built, data);
                return built;
            } catch (IOException e) {
                throw new CompletionException(e);
            }
        }, WORKER).whenComplete((built, error) -> MinecraftClient.getInstance().execute(() -> {
            if (error != null) {
                result.complete(describe(error));
                return;
            }
            initialized = true;
            installBuilt(built);
            CapeSettings.elytra = built.animated() ? "" : built.elytraSpec();
            CapeSettings.label = built.label();
            CapeSettings.save();
            String size = sizeText(built.capes()[0]);
            String note = CapeSettings.quality == 2 && built.capes()[0].getWidth() < 4096 && built.animated()
                    ? " That is the biggest size this many frames fit in memory."
                    : "";
            result.complete(built.animated()
                    ? "GIF cape applied! (" + built.capes().length + " frames, " + size + ")" + note
                    : "Cape applied! (" + size + ")");
        }));

        return result;
    }

    // ------------------------------------------------------------------ a pasted link

    /**
     * Downloads the picture or GIF a pasted link points to (http or https, nothing else is ever
     * contacted), saves it in config/bluecape/photos and makes it the cape. This is the only place the
     * mod uses the internet: no login, no account, no tracking. The future completes with a short
     * message for the screen, on the game thread.
     */
    public static CompletableFuture<String> importLink(String link) {
        final CompletableFuture<String> result = new CompletableFuture<>();
        CompletableFuture.supplyAsync(() -> {
            try {
                return download(link);
            } catch (IOException e) {
                throw new CompletionException(e);
            }
        }, WORKER).whenComplete((file, error) -> MinecraftClient.getInstance().execute(() -> {
            if (error != null) {
                result.complete(describeLink(error));
                return;
            }
            CapeSettings.lastPath = file.toString();        // so a later change of quality can redo it
            CapeSettings.save();
            importFile(file).thenAccept(result::complete);
        }));
        return result;
    }

    /** True for text that is a web link (so it is downloaded, not opened as a file path). */
    public static boolean looksLikeLink(String text) {
        String t = text.trim().toLowerCase(Locale.ROOT);
        return t.startsWith("http://") || t.startsWith("https://") || t.startsWith("www.");
    }

    /** Worker thread: fetches the link into config/bluecape/photos and returns the saved file. */
    private static Path download(String link) throws IOException {
        String text = link.trim();
        if (text.toLowerCase(Locale.ROOT).startsWith("www.")) {
            text = "https://" + text;
        }
        URI uri;
        try {
            uri = new URI(text);
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException("That doesn't look like a link.");
        }
        byte[] data = null;
        for (int hops = 0; hops < 6 && data == null; hops++) {
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
            if (!scheme.equals("http") && !scheme.equals("https")) {
                throw new IllegalArgumentException("A link must start with http:// or https://");
            }
            HttpURLConnection connection = (HttpURLConnection) uri.toURL().openConnection();
            try {
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(10_000);
                connection.setReadTimeout(20_000);
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (compatible; BlueCape)");
                connection.setRequestProperty("Accept", "image/gif,image/*;q=0.9,*/*;q=0.5");
                int code = connection.getResponseCode();
                if (code >= 300 && code < 400) {
                    String where = connection.getHeaderField("Location");
                    if (where == null || where.isBlank()) {
                        throw new IOException("The link sent us in a circle.");
                    }
                    try {
                        uri = uri.resolve(where);
                    } catch (IllegalArgumentException e) {
                        throw new IOException("The link sent us somewhere odd.");
                    }
                    continue;
                }
                if (code != 200) {
                    throw new IOException("The website answered " + code + ".");
                }
                if (connection.getContentLengthLong() > MAX_FILE_BYTES) {
                    throw new IllegalArgumentException("That file is too big (the limit is 40 MB).");
                }
                try (InputStream in = connection.getInputStream()) {
                    data = readLimited(in, MAX_FILE_BYTES);
                }
            } finally {
                connection.disconnect();
            }
        }
        if (data == null) {
            throw new IOException("The link sent us in a circle.");
        }
        String ext;
        if (GifDecoder.isGif(data)) {
            ext = "gif";
        } else if (data.length > 8 && (data[0] & 0xFF) == 0x89 && data[1] == 'P' && data[2] == 'N' && data[3] == 'G') {
            ext = "png";
        } else if (data.length > 3 && (data[0] & 0xFF) == 0xFF && (data[1] & 0xFF) == 0xD8 && (data[2] & 0xFF) == 0xFF) {
            ext = "jpg";
        } else if (data.length > 2 && data[0] == 'B' && data[1] == 'M') {
            ext = "bmp";
        } else {
            throw new IllegalArgumentException("That link is a web page, not a picture. Use the direct link to the file (it usually ends in .gif).");
        }
        Path dir = CapeSettings.dir().resolve("photos");
        Files.createDirectories(dir);
        Path file = dir.resolve("pasted_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT)
                .format(new java.util.Date()) + "." + ext);
        Files.write(file, data);
        return file;
    }

    private static byte[] readLimited(InputStream in, long limit) throws IOException {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buffer = new byte[64 * 1024];
        long total = 0;
        int n;
        while ((n = in.read(buffer)) != -1) {
            total += n;
            if (total > limit) {
                throw new IllegalArgumentException("That file is too big (the limit is 40 MB).");
            }
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }

    private static String describeLink(Throwable error) {
        Throwable t = error;
        while (t instanceof CompletionException && t.getCause() != null) {
            t = t.getCause();
        }
        LOG.warn("Link download failed", t);
        if (t instanceof IllegalArgumentException) {
            return String.valueOf(t.getMessage());
        }
        if (t instanceof UnknownHostException) {
            return "Can't reach that website. Is the internet on?";
        }
        if (t instanceof SocketTimeoutException) {
            return "That website took too long to answer.";
        }
        if (t instanceof IOException) {
            return "Could not download that: " + t.getMessage();
        }
        return describe(t);
    }

    /** Worker thread: file bytes in, textures-to-be out. */
    private static Built build(byte[] data, String name, CapeComposer.Fit fit, boolean readyMade) throws IOException {
        if (GifDecoder.isGif(data)) {
            return buildGif(data, name, fit, readyMade);
        }
        int orientation = CapeComposer.exifOrientation(data);
        try (NativeImage src = NativeImage.read(data)) {
            CapeComposer.Pixels raw = pixelsOfImage(src);
            int scale = stillScale();
            int[] pixels = readyMade
                    ? CapeComposer.fromReadyMade(raw, scale)
                    : CapeComposer.fromPhoto(CapeComposer.oriented(raw, orientation), fit, scale);
            return still(pixels, scale, readyMade, (readyMade ? "Cape file: " : "Photo: ") + shorten(name));
        }
    }

    private static Built buildGif(byte[] data, String name, CapeComposer.Fit fit, boolean readyMade) throws IOException {
        final int count = GifDecoder.countFrames(data);
        if (count == 1) {                                   // a GIF that does not move is just a photo
            final int[][] only = new int[1][];
            final int[] size = new int[2];
            GifDecoder.decode(data, (index, canvas, w, h, ms) -> {
                only[0] = canvas.clone();
                size[0] = w;
                size[1] = h;
            });
            CapeComposer.Pixels raw = pixelsOfArray(only[0], size[0], size[1]);
            int scale = stillScale();
            int[] pixels = readyMade ? CapeComposer.fromReadyMade(raw, scale) : CapeComposer.fromPhoto(raw, fit, scale);
            return still(pixels, scale, readyMade, (readyMade ? "Cape file: " : "Photo: ") + shorten(name));
        }

        final int step = Math.max(1, (count + MAX_FRAMES - 1) / MAX_FRAMES);
        final int scale = gifScale((count + step - 1) / step);      // as sharp as memory allows for this many frames
        final List<NativeImage> capes = new ArrayList<>();
        final List<Integer> delays = new ArrayList<>();
        final List<Integer> colors = new ArrayList<>();
        final List<int[]> capePreviews = new ArrayList<>();
        final List<int[]> wingPreviews = new ArrayList<>();
        try {
            GifDecoder.decode(data, (index, canvas, w, h, ms) -> {
                if (index % step != 0) {                    // a frame we skip: its time goes to the one before
                    int last = delays.size() - 1;
                    delays.set(last, delays.get(last) + ms);
                    return;
                }
                CapeComposer.Pixels raw = pixelsOfArray(canvas, w, h);
                int[] cape = readyMade
                        ? CapeComposer.fromReadyMade(raw, scale)
                        : CapeComposer.fromPhoto(raw, fit, scale);
                int cw = 64 * scale;
                int ch = 32 * scale;
                capes.add(toImage(cape, scale));
                delays.add(ms);
                colors.add(readyMade ? 0 : CapeComposer.averageColor(cape, scale));
                capePreviews.add(CapeComposer.capePreview(cape, cw, ch));
                wingPreviews.add(CapeComposer.wingPreview(cape, cw, ch));
            });
        } catch (IOException | RuntimeException e) {
            closeAll(capes.toArray(new NativeImage[0]));
            throw e;
        }
        int n = capes.size();
        int[] delayArray = new int[n];
        int[] colorArray = readyMade ? null : new int[n];
        for (int i = 0; i < n; i++) {
            delayArray[i] = delays.get(i);
            if (colorArray != null) {
                colorArray[i] = colors.get(i);
            }
        }
        return new Built(capes.toArray(new NativeImage[0]), delayArray, colorArray,
                capePreviews.toArray(new int[0][]), wingPreviews.toArray(new int[0][]),
                true, "", "GIF: " + shorten(name) + " (" + n + " frames)");
    }

    private static Built still(int[] pixels, int scale, boolean readyMade, String label) {
        int w = 64 * scale;
        int h = 32 * scale;
        String spec = readyMade ? "file" : String.format("#%06X", CapeComposer.averageColor(pixels, scale));
        int[] rgb = readyMade ? null : new int[]{CapeComposer.averageColor(pixels, scale)};
        return new Built(new NativeImage[]{toImage(pixels, scale)}, new int[]{1000}, rgb,
                new int[][]{CapeComposer.capePreview(pixels, w, h)}, new int[][]{CapeComposer.wingPreview(pixels, w, h)},
                false, spec, label);
    }

    /** Worker thread: remember the cape for the next launch. */
    private static void persist(Built built, byte[] gifBytes) {
        try {
            Files.createDirectories(CapeSettings.dir());
            if (built.animated()) {
                Files.write(CapeSettings.dir().resolve("cape.gif"), gifBytes);
                Files.deleteIfExists(CapeSettings.dir().resolve("cape.png"));
            } else {
                built.capes()[0].writeTo(CapeSettings.dir().resolve("cape.png"));
                Files.deleteIfExists(CapeSettings.dir().resolve("cape.gif"));
            }
        } catch (IOException e) {
            LOG.warn("Could not save the cape (it still works this session)", e);
        }
    }

    private static String shorten(String name) {
        return name.length() > 24 ? name.substring(0, 21) + "..." : name;
    }

    private static void closeAll(NativeImage[] images) {
        for (NativeImage image : images) {
            try {
                image.close();
            } catch (RuntimeException ignored) {
                // nothing more to do
            }
        }
    }

    private static String describe(Throwable error) {
        Throwable t = error;
        while (t instanceof CompletionException && t.getCause() != null) {
            t = t.getCause();
        }
        LOG.warn("Cape import failed", t);
        if (t instanceof NoSuchFileException) {
            return "File not found.";
        }
        if (t instanceof AccessDeniedException) {
            return "No permission to read that file. Copy it to config/bluecape/photos.";
        }
        if (t instanceof IllegalArgumentException) {
            return String.valueOf(t.getMessage());
        }
        if (t instanceof OutOfMemoryError) {
            return "That file is too big for the game's memory.";
        }
        if (t instanceof IOException) {
            return "Can't read that image. Use JPG, PNG, BMP or GIF (not WebP/HEIC).";
        }
        return "Failed: " + t;
    }

    // ------------------------------------------------------------------ pixels <-> images

    private static NativeImage toImage(int[] pixels, int scale) {
        int w = 64 * scale;
        int h = 32 * scale;
        NativeImage image = new NativeImage(w, h, true);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                image.setColorArgb(x, y, pixels[y * w + x]);
            }
        }
        return image;
    }

    private static int[] pixelsOf(NativeImage image) {
        int[] out = new int[image.getWidth() * image.getHeight()];
        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                out[y * image.getWidth() + x] = image.getColorArgb(x, y);
            }
        }
        return out;
    }

    private static CapeComposer.Pixels pixelsOfImage(NativeImage src) {
        return new CapeComposer.Pixels() {
            @Override
            public int width() {
                return src.getWidth();
            }

            @Override
            public int height() {
                return src.getHeight();
            }

            @Override
            public int argb(int x, int y) {
                return src.getColorArgb(x, y);
            }
        };
    }

    private static CapeComposer.Pixels pixelsOfArray(int[] px, int w, int h) {
        return new CapeComposer.Pixels() {
            @Override
            public int width() {
                return w;
            }

            @Override
            public int height() {
                return h;
            }

            @Override
            public int argb(int x, int y) {
                return px[y * w + x];
            }
        };
    }

    // ------------------------------------------------------------------ the game's elytra

    /** The game's own elytra picture, as plain pixels. */
    private record ElytraBase(int[] pixels, int width, int height) {
    }

    /**
     * The game's own elytra texture (whatever the active resource packs say).
     * Returns null when it can't be found, then the cape texture is used for the elytra.
     */
    private static ElytraBase loadVanillaElytra() {
        try {
            ResourceManager resources = MinecraftClient.getInstance().getResourceManager();
            Identifier canonical = Identifier.ofVanilla("textures/entity/equipment/wings/elytra.png");
            Identifier found = null;
            for (Identifier id : resources.findResources("textures/entity", p -> p.getPath().endsWith("elytra.png")).keySet()) {
                if (id.equals(canonical)) {
                    found = id;                      // the one the game really uses
                    break;
                }
                if ("minecraft".equals(id.getNamespace()) && id.getPath().endsWith("/elytra.png")
                        && (found == null || id.getPath().length() < found.getPath().length())) {
                    found = id;
                }
            }
            if (found == null) {
                LOG.warn("Could not find the game's elytra texture, using the cape texture for the elytra");
                return null;
            }
            try (InputStream in = resources.open(found); NativeImage src = NativeImage.read(in)) {
                return new ElytraBase(pixelsOf(src), src.getWidth(), src.getHeight());
            }
        } catch (Exception e) {
            LOG.warn("Could not read the elytra, using the cape texture for the elytra", e);
            return null;
        }
    }

    // ------------------------------------------------------------------ making textures (game thread)

    private static void installBuilt(Built b) {
        install(b.capes(), b.delays(), b.elytraRgb(), b.capePreview(), b.wingFromCape(), b.label());
    }

    private static void installStill(NativeImage image, int[] pixels, String elytraSpec, String label) {
        int w = image.getWidth();
        int h = image.getHeight();
        int[] rgb = null;
        if (!"file".equals(elytraSpec)) {
            int parsed = CapeComposer.parseHex(elytraSpec);
            rgb = new int[]{parsed < 0 ? (CapeComposer.BLUE & 0xFFFFFF) : parsed};
        }
        install(new NativeImage[]{image}, new int[]{1000}, rgb,
                new int[][]{CapeComposer.capePreview(pixels, w, h)}, new int[][]{CapeComposer.wingPreview(pixels, w, h)}, label);
    }

    /**
     * True when the wing area (the elytra part of the cape texture, x 24..34, y 2..22 on a 64x32 texture)
     * of any frame has more than one color, which means there is a picture to show on the wings.
     */
    private static boolean hasWingPicture(NativeImage[] capes) {
        for (NativeImage image : capes) {
            int s = image.getWidth() / 64;
            if (s < 1 || image.getHeight() < 22 * s) {
                continue;
            }
            int first = image.getColorArgb(24 * s, 2 * s);
            for (int y = 2 * s; y < 22 * s; y++) {
                for (int x = 24 * s; x < 34 * s; x++) {
                    if (image.getColorArgb(x, y) != first) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Game thread only. Registers fresh textures (one per frame) and drops the previous ones.
     * elytraRgb has one colour per frame (the game's elytra is tinted to it), or is null to use
     * the cape textures for the elytra too (a ready-made cape file brings its own wings).
     */
    private static void install(NativeImage[] capes, int[] delays, int[] elytraRgb,
                                int[][] capePreview, int[][] wingFromCape, String label) {
        TextureManager textures = MinecraftClient.getInstance().getTextureManager();
        int n = ++counter;
        int frames = capes.length;
        Installed next = new Installed();
        next.hasPicture = hasWingPicture(capes);            // looked at before the images become textures

        AssetInfo.TextureAsset[] capeAssets = new AssetInfo.TextureAsset[frames];
        for (int i = 0; i < frames; i++) {
            final Identifier id = Identifier.of("bluecape", "cape_" + n + "_" + i);
            final NativeImage image = capes[i];
            textures.registerTexture(id, new NativeImageBackedTexture(() -> "bluecape " + id, image));
            capeAssets[i] = new AssetInfo.TextureAssetInfo(id, id);
            next.ids.add(id);
        }

        AssetInfo.TextureAsset[] elytraAssets = capeAssets;
        int[][] wings = wingFromCape;
        ElytraBase base = elytraRgb == null ? null : loadVanillaElytra();
        if (base != null) {
            elytraAssets = new AssetInfo.TextureAsset[frames];
            wings = new int[frames][];
            Map<Integer, Integer> sameColor = new HashMap<>();      // frames with the same colour share one texture
            for (int i = 0; i < frames; i++) {
                int rgb = elytraRgb[i] & 0xFFFFFF;
                Integer twin = sameColor.get(rgb);
                if (twin != null) {
                    elytraAssets[i] = elytraAssets[twin];
                    wings[i] = wings[twin];
                    continue;
                }
                final int[] tinted = CapeComposer.recolorElytra(pixelsOfArray(base.pixels(), base.width(), base.height()), rgb);
                CapeComposer.fillElytraGaps(tinted, base.width(), base.height());
                final NativeImage image = new NativeImage(base.width(), base.height(), true);
                for (int y = 0; y < base.height(); y++) {
                    for (int x = 0; x < base.width(); x++) {
                        image.setColorArgb(x, y, tinted[y * base.width() + x]);
                    }
                }
                final Identifier id = Identifier.of("bluecape", "elytra_" + n + "_" + i);
                textures.registerTexture(id, new NativeImageBackedTexture(() -> "bluecape " + id, image));
                elytraAssets[i] = new AssetInfo.TextureAssetInfo(id, id);
                wings[i] = CapeComposer.wingPreview(tinted, base.width(), base.height());
                next.ids.add(id);
                sameColor.put(rgb, i);
            }
        }

        next.looks = new Look[frames];
        next.picLooks = new Look[frames];
        next.ends = new long[frames];
        long t = 0;
        for (int i = 0; i < frames; i++) {
            next.looks[i] = new Look(capeAssets[i], elytraAssets[i]);
            next.picLooks[i] = next.hasPicture ? new Look(capeAssets[i], capeAssets[i]) : next.looks[i];
            t += Math.max(20, delays[i]);
            next.ends[i] = t;
        }
        next.capePreview = capePreview;
        next.wingPreview = wings;
        next.picWingPreview = next.hasPicture ? wingFromCape : wings;
        next.startMs = nowMs();
        next.label = label;

        Installed old = current;
        current = next;
        if (old != null) {
            for (Identifier id : old.ids) {
                textures.destroyTexture(id);
            }
        }
    }
}
